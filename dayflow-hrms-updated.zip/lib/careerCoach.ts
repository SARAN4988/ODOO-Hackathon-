// ============================================================
// lib/careerCoach.ts
//
// The "AI Career & Promotion Coach" — rule-based, same philosophy as
// lib/copilot.ts (no external API key needed to run the demo). It
// blends tenure, skill depth/breadth, feedback and attendance
// reliability into a promotion-readiness read, then suggests which
// org-wide skill gaps this person is best placed to close next.
// ============================================================

export type OwnSkill = { skill_name: string; category: string; proficiency: number };
export type SkillGapLite = { skill: string; category: string; severity: "Critical" | "Watch" | "Healthy" };

export type ReadinessBand = "Building foundation" | "Growing" | "Promotion-ready" | "Strong promotion case";

export type CareerCoachReport = {
  readinessScore: number; // 0-100
  band: ReadinessBand;
  strengths: string[];
  growthAreas: string[];
  recommendedSkills: string[]; // org-critical gaps this person doesn't have yet, worth picking up
  narrative: string;
};

function tenureComponent(months: number): number {
  // Ramps up to 12 months, then plateaus — tenure alone shouldn't
  // dominate the score once someone's past the ramp-up period.
  return Math.round(Math.min(100, (months / 12) * 100));
}

function skillDepthComponent(skills: OwnSkill[]): number {
  if (!skills.length) return 0;
  const strong = skills.filter((s) => s.proficiency >= 4).length;
  const breadth = Math.min(skills.length, 8) / 8; // logging a spread of skills counts, capped
  const depth = Math.min(strong, 5) / 5; // having several strong skills counts more
  return Math.round((breadth * 0.4 + depth * 0.6) * 100);
}

function feedbackComponent(avgRating: number | null): number {
  if (avgRating == null) return 50; // neutral when there's no data yet, same as analytics.ts
  return Math.round(Math.max(0, Math.min(100, ((avgRating - 1) / 4) * 100)));
}

function reliabilityComponent(presentRate: number): number {
  return Math.round(Math.max(0, Math.min(100, presentRate)));
}

export function buildCareerCoachReport(input: {
  tenureMonths: number;
  skills: OwnSkill[];
  avgFeedbackRating: number | null;
  presentRate: number; // 0-100, from analytics.attendanceSummary
  orgSkillGaps: SkillGapLite[]; // from analyzeSkillGaps, org-wide
}): CareerCoachReport {
  const tenure = tenureComponent(input.tenureMonths);
  const depth = skillDepthComponent(input.skills);
  const feedback = feedbackComponent(input.avgFeedbackRating);
  const reliability = reliabilityComponent(input.presentRate);

  // Weighted blend: skill depth and reliability matter most for a
  // promotion case; tenure and feedback support it.
  const readinessScore = Math.round(depth * 0.35 + reliability * 0.25 + feedback * 0.25 + tenure * 0.15);

  let band: ReadinessBand = "Building foundation";
  if (readinessScore >= 80) band = "Strong promotion case";
  else if (readinessScore >= 60) band = "Promotion-ready";
  else if (readinessScore >= 35) band = "Growing";

  const strengths: string[] = [];
  if (depth >= 65) strengths.push("Broad, deep skill profile");
  if (reliability >= 90) strengths.push("Highly reliable attendance");
  if (feedback >= 75) strengths.push("Strong feedback ratings");
  if (tenure >= 90) strengths.push("Well past the ramp-up period");
  const strongSkills = input.skills.filter((s) => s.proficiency >= 4).map((s) => s.skill_name);
  if (strongSkills.length) strengths.push(`Expert-level in ${strongSkills.slice(0, 3).join(", ")}`);

  const growthAreas: string[] = [];
  if (depth < 65) growthAreas.push("Skill depth — log more skills and push a few toward expert level (4-5/5)");
  if (reliability < 90) growthAreas.push("Attendance consistency");
  if (feedback < 75) growthAreas.push("Feedback ratings — worth a check-in with your manager on specifics");
  if (tenure < 90) growthAreas.push("Still in the ramp-up window — this naturally improves with time");
  if (!strengths.length) strengths.push("Keep logging skills and feedback so the coach has more to work with");

  // Recommend org-critical skill gaps this person hasn't logged yet —
  // picking one up is a high-leverage way to stand out.
  const ownSkillNames = new Set(input.skills.map((s) => s.skill_name));
  const recommendedSkills = input.orgSkillGaps
    .filter((g) => g.severity !== "Healthy" && !ownSkillNames.has(g.skill))
    .slice(0, 4)
    .map((g) => g.skill);

  const narrative =
    band === "Strong promotion case"
      ? "Your profile reads strongly across the board — this is a good time to bring up promotion or scope expansion with your manager."
      : band === "Promotion-ready"
      ? "You're in solid shape. Closing one or two of the growth areas below would make the case even clearer."
      : band === "Growing"
      ? "You're building real momentum. Focus on the growth areas below over the next few months."
      : "Early days — the foundation matters most right now. Logging skills and staying consistent will move this score fastest.";

  return { readinessScore, band, strengths, growthAreas, recommendedSkills, narrative };
}
