// ============================================================
// lib/payrollAnomaly.ts
//
// Rule-based payroll anomaly detection — no ML model, just
// explainable statistical checks so every flag traces back to a
// number you can verify in the SQL editor. Same philosophy as the
// rest of lib/.
// ============================================================

export type SalaryRow = {
  user_id: string;
  base_salary: number;
  allowances: Record<string, number> | null;
  deductions: Record<string, number> | null;
  effective_date: string; // YYYY-MM-DD
};

export type EmployeeLite = { id: string; full_name: string; department: string | null; job_title: string | null };

export type PayrollAnomaly = {
  id: string;
  userId: string;
  employeeName: string;
  type: "band-outlier" | "sudden-change" | "no-salary-on-file" | "deductions-exceed-pay";
  severity: "Critical" | "Watch";
  detail: string;
};

function sum(obj: Record<string, number> | null | undefined): number {
  if (!obj) return 0;
  return Object.values(obj).reduce((a, b) => a + (Number(b) || 0), 0);
}

function mean(nums: number[]): number {
  return nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : 0;
}

function stddev(nums: number[]): number {
  if (nums.length < 2) return 0;
  const m = mean(nums);
  return Math.sqrt(nums.reduce((s, n) => s + (n - m) ** 2, 0) / nums.length);
}

// ---------- band outliers ----------
// Groups the latest salary record per employee by department, then
// flags anyone more than 1.75 standard deviations from their
// department's mean base salary. Departments with fewer than 3
// people are skipped — not enough of a peer group to judge from.
export function detectBandOutliers(latestByEmployee: (SalaryRow & { department: string | null })[]): PayrollAnomaly[] {
  const byDept = new Map<string, (SalaryRow & { department: string | null })[]>();
  for (const row of latestByEmployee) {
    const dept = row.department || "Unassigned";
    const arr = byDept.get(dept) ?? [];
    arr.push(row);
    byDept.set(dept, arr);
  }

  const anomalies: PayrollAnomaly[] = [];
  for (const [, rows] of byDept) {
    if (rows.length < 3) continue;
    const salaries = rows.map((r) => r.base_salary);
    const m = mean(salaries);
    const sd = stddev(salaries);
    if (sd === 0) continue;
    for (const r of rows) {
      const z = (r.base_salary - m) / sd;
      if (Math.abs(z) >= 1.75) {
        const direction = z > 0 ? "above" : "below";
        anomalies.push({
          id: `band-${r.user_id}`,
          userId: r.user_id,
          employeeName: "",
          type: "band-outlier",
          severity: Math.abs(z) >= 2.5 ? "Critical" : "Watch",
          detail: `Base salary is ${direction} the department average by ${Math.abs(z).toFixed(1)}σ (dept avg ≈ ${Math.round(m).toLocaleString()}).`,
        });
      }
    }
  }
  return anomalies;
}

// ---------- sudden change between consecutive records ----------
// Looks at each employee's salary history in order and flags any
// jump/drop of 25%+ in base salary between two consecutive records —
// legitimate raises are usually smaller and gradual, and this also
// catches fat-finger entry errors.
export function detectSuddenChanges(historyByEmployee: Map<string, SalaryRow[]>, thresholdPct = 25): PayrollAnomaly[] {
  const anomalies: PayrollAnomaly[] = [];
  for (const [userId, rows] of historyByEmployee) {
    const sorted = [...rows].sort((a, b) => a.effective_date.localeCompare(b.effective_date));
    for (let i = 1; i < sorted.length; i++) {
      const prev = sorted[i - 1].base_salary;
      const curr = sorted[i].base_salary;
      if (!prev) continue;
      const changePct = ((curr - prev) / prev) * 100;
      if (Math.abs(changePct) >= thresholdPct) {
        anomalies.push({
          id: `change-${userId}-${sorted[i].effective_date}`,
          userId,
          employeeName: "",
          type: "sudden-change",
          severity: Math.abs(changePct) >= 50 ? "Critical" : "Watch",
          detail: `Base salary ${changePct > 0 ? "jumped" : "dropped"} ${Math.abs(Math.round(changePct))}% on ${sorted[i].effective_date} (from ${prev.toLocaleString()} to ${curr.toLocaleString()}).`,
        });
      }
    }
  }
  return anomalies;
}

// ---------- deductions exceeding pay ----------
export function detectDeductionsExceedPay(latestByEmployee: SalaryRow[]): PayrollAnomaly[] {
  return latestByEmployee
    .filter((r) => sum(r.deductions) > r.base_salary + sum(r.allowances))
    .map((r) => ({
      id: `deduct-${r.user_id}`,
      userId: r.user_id,
      employeeName: "",
      type: "deductions-exceed-pay" as const,
      severity: "Critical" as const,
      detail: `Deductions (${sum(r.deductions).toLocaleString()}) exceed base + allowances (${(r.base_salary + sum(r.allowances)).toLocaleString()}).`,
    }));
}

// ---------- no salary on file ----------
export function detectMissingSalary(employees: EmployeeLite[], employeeIdsWithSalary: Set<string>): PayrollAnomaly[] {
  return employees
    .filter((e) => !employeeIdsWithSalary.has(e.id))
    .map((e) => ({
      id: `missing-${e.id}`,
      userId: e.id,
      employeeName: e.full_name,
      type: "no-salary-on-file" as const,
      severity: "Watch" as const,
      detail: "No salary structure has ever been set for this employee.",
    }));
}

export function attachNames(anomalies: PayrollAnomaly[], nameOf: Map<string, string>): PayrollAnomaly[] {
  return anomalies.map((a) => ({ ...a, employeeName: a.employeeName || nameOf.get(a.userId) || "Unknown" }));
}

const SEVERITY_RANK: Record<PayrollAnomaly["severity"], number> = { Critical: 0, Watch: 1 };
export function sortAnomalies(anomalies: PayrollAnomaly[]): PayrollAnomaly[] {
  return [...anomalies].sort((a, b) => SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity]);
}
