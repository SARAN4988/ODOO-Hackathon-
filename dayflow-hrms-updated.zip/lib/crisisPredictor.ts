// ============================================================
// lib/crisisPredictor.ts
//
// The "Workforce Crisis Predictor" — takes signals that already
// exist elsewhere in the app (per-employee risk from analytics.ts,
// department coverage from the Planning page's own math, and skill
// concentration from skillIntelligence.ts) and fuses them into one
// org-wide early-warning score plus a ranked list of concrete
// alerts. Same philosophy as the rest of lib/ — small, named,
// explainable functions, no black box.
// ============================================================

export type EmployeeRiskLite = { id: string; name: string; department: string; overall: number };
export type DeptCapacityLite = { department: string; headcount: number; weeks: number[] }; // weeks[i] = % capacity that week
export type BusFactorLite = { skill: string; busFactor: number; severity: "Critical" | "Watch" | "Healthy" };

export type CrisisSeverity = "Stable" | "Watch" | "Elevated" | "Critical";

export type CrisisSignal = {
  id: string;
  type: "attrition" | "coverage" | "skill-concentration" | "morale";
  severity: CrisisSeverity;
  title: string;
  detail: string;
  score: number; // 0-100, this signal's own contribution scale
};

// ---------- attrition signal ----------
// % of the org sitting at "Elevated" overall risk (>=60, same
// threshold Risk Radar uses to color a row red-ish).
export function attritionSignal(employeeRisks: EmployeeRiskLite[]): CrisisSignal {
  const total = employeeRisks.length;
  const elevated = employeeRisks.filter((e) => e.overall >= 60);
  const pct = total ? Math.round((elevated.length / total) * 100) : 0;

  let severity: CrisisSeverity = "Stable";
  if (pct >= 30) severity = "Critical";
  else if (pct >= 15) severity = "Elevated";
  else if (pct >= 5) severity = "Watch";

  const topDept = mostCommonDept(elevated);
  return {
    id: "attrition",
    type: "attrition",
    severity,
    score: Math.min(100, pct * 3),
    title: `${pct}% of the org is at elevated attrition risk`,
    detail:
      elevated.length === 0
        ? "No one is currently flagged at elevated overall risk."
        : `${elevated.length} employee${elevated.length === 1 ? "" : "s"} above the risk threshold` +
          (topDept ? `, concentrated in ${topDept}.` : "."),
  };
}

function mostCommonDept(rows: { department: string }[]): string | null {
  if (!rows.length) return null;
  const counts = new Map<string, number>();
  for (const r of rows) counts.set(r.department, (counts.get(r.department) ?? 0) + 1);
  return [...counts.entries()].sort((a, b) => b[1] - a[1])[0][0];
}

// ---------- coverage signal ----------
// Reuses the same "% of department not on approved leave" numbers
// the Planning page renders per week. A crisis is a department
// dropping under 70% capacity in any of the next 4 weeks.
export function coverageCrisisSignal(departments: DeptCapacityLite[], weekLabels: string[]): CrisisSignal {
  const breaches: { department: string; week: string; capacity: number }[] = [];
  for (const dept of departments) {
    dept.weeks.forEach((capacity, i) => {
      if (capacity < 70) breaches.push({ department: dept.department, week: weekLabels[i] ?? `Week ${i + 1}`, capacity });
    });
  }
  const worst = breaches.sort((a, b) => a.capacity - b.capacity)[0];

  let severity: CrisisSeverity = "Stable";
  if (breaches.some((b) => b.capacity < 50)) severity = "Critical";
  else if (breaches.length >= 2) severity = "Elevated";
  else if (breaches.length === 1) severity = "Watch";

  return {
    id: "coverage",
    type: "coverage",
    severity,
    score: worst ? Math.min(100, (100 - worst.capacity) * 1.4) : 0,
    title: breaches.length ? `${breaches.length} department/week pairing${breaches.length === 1 ? "" : "s"} under 70% capacity` : "Coverage looks healthy",
    detail: worst
      ? `${worst.department} drops to ${worst.capacity}% capacity in "${worst.week}" from approved leave alone.`
      : "No department is projected to dip below 70% capacity in the next 4 weeks.",
  };
}

// ---------- skill concentration signal ----------
// A "bus factor" of 1 on a skill the org actually relies on is a
// single-point-of-failure risk — this just counts how many of those
// exist right now (see lib/skillIntelligence.ts for the detection).
export function skillConcentrationSignal(busFactorRisks: BusFactorLite[]): CrisisSignal {
  const critical = busFactorRisks.filter((b) => b.severity === "Critical");
  let severity: CrisisSeverity = "Stable";
  if (critical.length >= 5) severity = "Critical";
  else if (critical.length >= 2) severity = "Elevated";
  else if (critical.length === 1) severity = "Watch";

  return {
    id: "skill-concentration",
    type: "skill-concentration",
    severity,
    score: Math.min(100, critical.length * 22),
    title: `${critical.length} skill${critical.length === 1 ? "" : "s"} held at expert level by only one person`,
    detail: critical.length
      ? `${critical.slice(0, 3).map((c) => c.skill).join(", ")}${critical.length > 3 ? ", …" : ""} — losing that one person stalls the work.`
      : "No single-person dependencies among expert-level skills right now.",
  };
}

// ---------- morale signal ----------
// Low org-wide average feedback rating, weighted toward recency isn't
// tracked separately here — feedback rows already skew recent since
// the feature is new — so a straight average is a fair proxy.
export function moraleSignal(ratings: number[]): CrisisSignal {
  if (!ratings.length) {
    return {
      id: "morale",
      type: "morale",
      severity: "Stable",
      score: 0,
      title: "Not enough feedback yet to score morale",
      detail: "Encourage a few more submissions on the Feedback page for a reliable read.",
    };
  }
  const avg = ratings.reduce((a, b) => a + b, 0) / ratings.length;
  let severity: CrisisSeverity = "Stable";
  if (avg < 2.5) severity = "Critical";
  else if (avg < 3.2) severity = "Elevated";
  else if (avg < 3.8) severity = "Watch";

  return {
    id: "morale",
    type: "morale",
    severity,
    score: Math.round(Math.max(0, (4 - avg) * 33)),
    title: `Org-wide average feedback rating: ${avg.toFixed(1)} / 5`,
    detail: `Based on ${ratings.length} submitted feedback entr${ratings.length === 1 ? "y" : "ies"}.`,
  };
}

// ---------- combine ----------
const SEVERITY_WEIGHT: Record<CrisisSeverity, number> = { Stable: 0, Watch: 1, Elevated: 2, Critical: 3 };

export function combineCrisisScore(signals: CrisisSignal[]): { score: number; level: CrisisSeverity } {
  const avg = signals.length ? signals.reduce((s, sig) => s + sig.score, 0) / signals.length : 0;
  const score = Math.round(avg);
  const maxWeight = Math.max(0, ...signals.map((s) => SEVERITY_WEIGHT[s.severity]));
  const level = (Object.keys(SEVERITY_WEIGHT) as CrisisSeverity[]).find((l) => SEVERITY_WEIGHT[l] === maxWeight) ?? "Stable";
  return { score, level };
}
