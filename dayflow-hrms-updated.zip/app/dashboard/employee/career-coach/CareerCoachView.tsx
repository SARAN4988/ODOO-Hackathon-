"use client";

import Link from "next/link";
import { Card } from "@/components/Card";
import type { CareerCoachReport } from "@/lib/careerCoach";

const BAND_STYLES: Record<string, string> = {
  "Building foundation": "bg-slate/10 text-slate",
  Growing: "bg-warn/10 text-warn",
  "Promotion-ready": "bg-flow-light text-flow-dark",
  "Strong promotion case": "bg-ok/10 text-ok",
};

export function CareerCoachView({ report, skillCount }: { report: CareerCoachReport; skillCount: number }) {
  return (
    <div className="space-y-6">
      <Card>
        <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-slate">Readiness score</p>
            <p className="font-display text-4xl font-semibold text-ink">{report.readinessScore}</p>
          </div>
          <span className={`rounded-full px-4 py-2 text-sm font-medium ${BAND_STYLES[report.band]}`}>{report.band}</span>
        </div>
        <p className="mt-4 text-sm text-slate">{report.narrative}</p>
      </Card>

      <div className="grid gap-4 sm:grid-cols-2">
        <Card>
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">Strengths</h2>
          <ul className="mt-3 space-y-2 text-sm text-ink">
            {report.strengths.map((s, i) => (
              <li key={i} className="flex gap-2">
                <span className="text-ok">✓</span>
                <span>{s}</span>
              </li>
            ))}
          </ul>
        </Card>
        <Card>
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">Growth areas</h2>
          <ul className="mt-3 space-y-2 text-sm text-ink">
            {report.growthAreas.map((g, i) => (
              <li key={i} className="flex gap-2">
                <span className="text-warn">→</span>
                <span>{g}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <Card>
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Skills worth picking up next
        </h2>
        <p className="mt-1 text-xs text-slate">
          Org-wide gaps you haven't logged yet — closing one is a high-leverage way to stand out.
        </p>
        {report.recommendedSkills.length ? (
          <div className="mt-3 flex flex-wrap gap-2">
            {report.recommendedSkills.map((s) => (
              <span key={s} className="rounded-full bg-flow-light px-3 py-1 text-sm font-medium text-flow-dark">
                {s}
              </span>
            ))}
          </div>
        ) : (
          <p className="mt-3 text-sm text-slate">No pressing org-wide gaps match right now — nice position to be in.</p>
        )}
        {skillCount === 0 && (
          <p className="mt-4 text-sm text-slate">
            You haven't logged any skills yet —{" "}
            <Link href="/dashboard/employee/skills" className="font-medium text-flow">
              add a few on My Skills
            </Link>{" "}
            for a more accurate read.
          </p>
        )}
      </Card>
    </div>
  );
}
