import { createClient, getUserProfile } from "@/lib/supabase/server";
import { attendanceSummary, tenureMonths } from "@/lib/analytics";
import { analyzeSkillGaps } from "@/lib/skillIntelligence";
import { buildCareerCoachReport } from "@/lib/careerCoach";
import { CareerCoachView } from "./CareerCoachView";

export default async function CareerCoachPage() {
  const { user, profile } = await getUserProfile();
  const supabase = createClient();
  const now = new Date();
  const cutoff90 = new Date(now);
  cutoff90.setDate(cutoff90.getDate() - 90);

  const [{ data: mySkills }, { data: myFeedback }, { data: myAttendance }, { data: allSkills }, { count: totalEmployees }] =
    await Promise.all([
      supabase.from("skills").select("skill_name, category, proficiency").eq("user_id", user!.id),
      supabase.from("feedback").select("rating").eq("user_id", user!.id),
      supabase
        .from("attendance")
        .select("date, status")
        .eq("user_id", user!.id)
        .gte("date", cutoff90.toISOString().slice(0, 10)),
      supabase.from("skills").select("user_id, skill_name, category, proficiency"),
      supabase.from("users").select("id", { count: "exact", head: true }).eq("role", "employee"),
    ]);

  const ratings = ((myFeedback ?? []) as { rating: number }[]).map((f) => f.rating);
  const avgFeedbackRating = ratings.length ? ratings.reduce((a, b) => a + b, 0) / ratings.length : null;
  const { presentRate } = attendanceSummary((myAttendance as any) ?? []);
  const orgSkillGaps = analyzeSkillGaps((allSkills as any) ?? [], totalEmployees ?? 0);

  const report = buildCareerCoachReport({
    tenureMonths: tenureMonths(profile?.date_joined),
    skills: (mySkills as any) ?? [],
    avgFeedbackRating,
    presentRate,
    orgSkillGaps,
  });

  return (
    <div className="mx-auto max-w-4xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Career &amp; Promotion Coach</h1>
      <p className="mt-1 text-sm text-slate">
        A rule-based read on your promotion readiness, built from your logged skills, feedback, tenure and
        attendance — not a guarantee or an official review, just a prompt to have the conversation.
      </p>
      <div className="mt-6">
        <CareerCoachView report={report} skillCount={(mySkills as any)?.length ?? 0} />
      </div>
    </div>
  );
}
