"use client";

import { Card } from "@/components/Card";
import { detectBusFactor, type SkillRow, type EmployeeOption } from "@/lib/skillIntelligence";

const SEVERITY_STYLES: Record<string, string> = {
  Critical: "bg-bad/10 text-bad",
  Watch: "bg-warn/10 text-warn",
  Healthy: "bg-ok/10 text-ok",
};

export function BusFactor({ skills, employees }: { skills: SkillRow[]; employees: EmployeeOption[] }) {
  const risks = detectBusFactor(skills, employees);
  const critical = risks.filter((r) => r.severity === "Critical");

  return (
    <div className="space-y-6">
      <Card>
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Single points of failure
        </h2>
        <p className="mt-1 text-sm text-slate">
          "Bus factor" = how many people are logged at expert level (4-5 / 5) on a skill. A bus factor of 1
          means exactly one person could take that capability out the door with them.
        </p>
        <div className="mt-4 flex gap-6 text-sm">
          <div>
            <p className="font-display text-2xl font-semibold text-bad">{critical.length}</p>
            <p className="text-slate">skills at bus factor 1</p>
          </div>
          <div>
            <p className="font-display text-2xl font-semibold text-ink">{risks.length}</p>
            <p className="text-slate">skills with any expert-level coverage</p>
          </div>
        </div>
      </Card>

      <Card className="!p-0">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-slate">
              <th className="px-6 py-3 font-medium">Skill</th>
              <th className="px-6 py-3 font-medium">Category</th>
              <th className="px-6 py-3 font-medium">Bus factor</th>
              <th className="px-6 py-3 font-medium">Expert holder(s)</th>
              <th className="px-6 py-3 font-medium">Severity</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {risks.map((r) => (
              <tr key={r.skill}>
                <td className="px-6 py-3 text-ink">{r.skill}</td>
                <td className="px-6 py-3 text-slate">{r.category}</td>
                <td className="px-6 py-3 font-semibold text-ink">{r.busFactor}</td>
                <td className="px-6 py-3 text-slate">{r.holders.map((h) => h.name).join(", ")}</td>
                <td className="px-6 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${SEVERITY_STYLES[r.severity]}`}>
                    {r.severity}
                  </span>
                </td>
              </tr>
            ))}
            {risks.length === 0 && (
              <tr>
                <td colSpan={5} className="px-6 py-6 text-center text-slate">
                  No expert-level skills logged yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
        <div className="h-2" />
      </Card>
    </div>
  );
}
