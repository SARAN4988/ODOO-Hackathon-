import { createClient } from "@/lib/supabase/server";
import { buildRiskProfile } from "@/lib/analytics";
import { detectBusFactor } from "@/lib/skillIntelligence";
import {
  attritionSignal,
  coverageCrisisSignal,
  skillConcentrationSignal,
  moraleSignal,
  combineCrisisScore,
  type DeptCapacityLite,
} from "@/lib/crisisPredictor";
import { CrisisView } from "./CrisisView";

function startOfWeek(d: Date) {
  const date = new Date(d);
  const day = date.getDay();
  const diff = (day === 0 ? -6 : 1) - day;
  date.setDate(date.getDate() + diff);
  date.setHours(0, 0, 0, 0);
  return date;
}
const toDateStr = (d: Date) => d.toISOString().slice(0, 10);

export default async function CrisisPredictorPage() {
  const supabase = createClient();
  const now = new Date();
  const cutoff90 = new Date(now);
  cutoff90.setDate(cutoff90.getDate() - 90);
  const cutoff12mo = new Date(now);
  cutoff12mo.setMonth(cutoff12mo.getMonth() - 12);

  const [{ data: users }, { data: attendance }, { data: allLeaves }, { data: feedback }, { data: skills }] =
    await Promise.all([
      supabase.from("users").select("id, full_name, department, date_joined").eq("role", "employee"),
      supabase.from("attendance").select("user_id, date, status").gte("date", cutoff90.toISOString().slice(0, 10)),
      supabase
        .from("leave_requests")
        .select("user_id, start_date, end_date, status")
        .gte("created_at", cutoff12mo.toISOString()),
      supabase.from("feedback").select("user_id, rating"),
      supabase.from("skills").select("user_id, skill_name, category, proficiency"),
    ]);

  const employees = (users ?? []) as { id: string; full_name: string; department: string | null; date_joined: string | null }[];

  // ---- per-employee risk (same math as the Risk Radar page) ----
  const attendanceByUser = new Map<string, any[]>();
  for (const a of (attendance ?? []) as any[]) {
    const arr = attendanceByUser.get(a.user_id) ?? [];
    arr.push(a);
    attendanceByUser.set(a.user_id, arr);
  }
  const leavesByUser = new Map<string, any[]>();
  for (const l of (allLeaves ?? []) as any[]) {
    const arr = leavesByUser.get(l.user_id) ?? [];
    arr.push(l);
    leavesByUser.set(l.user_id, arr);
  }
  const feedbackByUser = new Map<string, number[]>();
  for (const f of (feedback ?? []) as any[]) {
    const arr = feedbackByUser.get(f.user_id) ?? [];
    arr.push(f.rating);
    feedbackByUser.set(f.user_id, arr);
  }

  const employeeRisks = employees.map((u) => {
    const ratings = feedbackByUser.get(u.id) ?? [];
    const avgFeedbackRating = ratings.length ? ratings.reduce((a, b) => a + b, 0) / ratings.length : null;
    const { overall } = buildRiskProfile({
      attendance: attendanceByUser.get(u.id) ?? [],
      leaves: leavesByUser.get(u.id) ?? [],
      avgFeedbackRating,
      dateJoined: u.date_joined,
    });
    return { id: u.id, name: u.full_name, department: u.department || "Unassigned", overall };
  });

  // ---- department capacity, next 4 weeks (same math as the Planning page) ----
  const approvedLeaves = ((allLeaves ?? []) as any[]).filter((l) => l.status === "approved") as {
    user_id: string;
    start_date: string;
    end_date: string;
  }[];
  const deptOf = new Map(employees.map((e) => [e.id, e.department || "Unassigned"]));
  const headcountByDept = new Map<string, number>();
  for (const e of employees) {
    const dept = e.department || "Unassigned";
    headcountByDept.set(dept, (headcountByDept.get(dept) || 0) + 1);
  }
  const weekStarts: Date[] = [];
  const base = startOfWeek(now);
  for (let i = 0; i < 4; i++) {
    const d = new Date(base);
    d.setDate(d.getDate() + i * 7);
    weekStarts.push(d);
  }
  const weekLabels = weekStarts.map((d, i) =>
    i === 0 ? "This week" : `Wk of ${d.toLocaleDateString(undefined, { month: "short", day: "numeric" })}`
  );
  const departmentCapacity: DeptCapacityLite[] = Array.from(headcountByDept.keys()).map((dept) => {
    const headcount = headcountByDept.get(dept) || 0;
    const weeks = weekStarts.map((weekStart) => {
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);
      const weekStartStr = toDateStr(weekStart);
      const weekEndStr = toDateStr(weekEnd);
      const onLeaveThatWeek = new Set(
        approvedLeaves
          .filter((l) => (deptOf.get(l.user_id) || "Unassigned") === dept)
          .filter((l) => l.start_date <= weekEndStr && l.end_date >= weekStartStr)
          .map((l) => l.user_id)
      ).size;
      return headcount ? Math.round(((headcount - onLeaveThatWeek) / headcount) * 100) : 100;
    });
    return { department: dept, headcount, weeks };
  });

  // ---- skill concentration (bus factor) ----
  const busFactorRisks = detectBusFactor((skills as any) ?? [], employees.map((e) => ({ id: e.id, full_name: e.full_name, department: e.department })));

  // ---- fuse into signals + overall score ----
  const signals = [
    attritionSignal(employeeRisks),
    coverageCrisisSignal(departmentCapacity, weekLabels),
    skillConcentrationSignal(busFactorRisks),
    moraleSignal(((feedback ?? []) as any[]).map((f) => f.rating)),
  ];
  const { score, level } = combineCrisisScore(signals);

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Workforce Crisis Predictor</h1>
      <p className="mt-1 text-sm text-slate">
        Fuses attrition risk, department coverage, skill concentration and morale into one early-warning read —
        so a brewing problem shows up before it becomes an actual crisis.
      </p>
      <div className="mt-6">
        <CrisisView score={score} level={level} signals={signals} employeeRisks={employeeRisks} />
      </div>
    </div>
  );
}
