"use client";

import { Card } from "@/components/Card";
import type { CrisisSignal, CrisisSeverity } from "@/lib/crisisPredictor";

const SEVERITY_STYLES: Record<CrisisSeverity, string> = {
  Stable: "bg-ok/10 text-ok",
  Watch: "bg-warn/10 text-warn",
  Elevated: "bg-warn/10 text-warn",
  Critical: "bg-bad/10 text-bad",
};

const SEVERITY_RING: Record<CrisisSeverity, string> = {
  Stable: "#1E9E6C",
  Watch: "#C98A1B",
  Elevated: "#C98A1B",
  Critical: "#D8475C",
};

const TYPE_LABEL: Record<CrisisSignal["type"], string> = {
  attrition: "Attrition",
  coverage: "Coverage",
  "skill-concentration": "Skill concentration",
  morale: "Morale",
};

function Gauge({ score, level }: { score: number; level: CrisisSeverity }) {
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const filled = (Math.min(100, Math.max(0, score)) / 100) * circumference;
  return (
    <div className="flex flex-col items-center justify-center">
      <svg width="180" height="180" viewBox="0 0 180 180">
        <circle cx="90" cy="90" r={radius} fill="none" stroke="#E3E6EF" strokeWidth="14" />
        <circle
          cx="90"
          cy="90"
          r={radius}
          fill="none"
          stroke={SEVERITY_RING[level]}
          strokeWidth="14"
          strokeDasharray={`${filled} ${circumference}`}
          strokeLinecap="round"
          transform="rotate(-90 90 90)"
        />
        <text x="90" y="84" textAnchor="middle" className="font-display" fontSize="34" fontWeight={700} fill="#171A2B">
          {score}
        </text>
        <text x="90" y="106" textAnchor="middle" fontSize="12" fill="#4B5468">
          crisis score
        </text>
      </svg>
      <span className={`mt-2 rounded-full px-3 py-1 text-sm font-medium ${SEVERITY_STYLES[level]}`}>{level}</span>
    </div>
  );
}

export function CrisisView({
  score,
  level,
  signals,
  employeeRisks,
}: {
  score: number;
  level: CrisisSeverity;
  signals: CrisisSignal[];
  employeeRisks: { id: string; name: string; department: string; overall: number }[];
}) {
  const topAtRisk = [...employeeRisks].sort((a, b) => b.overall - a.overall).slice(0, 6);

  return (
    <div className="space-y-6">
      <Card>
        <div className="flex flex-col items-center gap-6 sm:flex-row sm:items-start">
          <Gauge score={score} level={level} />
          <div className="flex-1">
            <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
              Overall workforce crisis read
            </h2>
            <p className="mt-1 text-sm text-slate">
              A blend of four signals below (0 = no signs of trouble, 100 = act now). This is a rule-based
              early-warning heuristic, not a prediction of any individual's future behavior — treat it as a
              prompt to look closer, not a verdict.
            </p>
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {signals.map((s) => (
                <div key={s.id} className="rounded-lg border border-line px-3 py-2">
                  <p className="text-xs text-slate">{TYPE_LABEL[s.type]}</p>
                  <span className={`mt-1 inline-block rounded-full px-2 py-0.5 text-xs font-medium ${SEVERITY_STYLES[s.severity]}`}>
                    {s.severity}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Card>

      <div className="space-y-4">
        {signals.map((s) => (
          <Card key={s.id}>
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-slate">{TYPE_LABEL[s.type]}</p>
                <h3 className="mt-1 font-display text-base font-semibold text-ink">{s.title}</h3>
                <p className="mt-1 text-sm text-slate">{s.detail}</p>
              </div>
              <span className={`shrink-0 rounded-full px-3 py-1 text-xs font-medium ${SEVERITY_STYLES[s.severity]}`}>
                {s.severity}
              </span>
            </div>
          </Card>
        ))}
      </div>

      <Card className="!p-0">
        <div className="p-6 pb-0">
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
            Employees driving the attrition signal
          </h2>
          <p className="mt-1 text-xs text-slate">Same overall risk score as the Risk Radar page, ranked here.</p>
        </div>
        <table className="mt-4 w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-slate">
              <th className="px-6 py-3 font-medium">Employee</th>
              <th className="px-6 py-3 font-medium">Department</th>
              <th className="px-6 py-3 font-medium">Overall risk</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {topAtRisk.map((e) => (
              <tr key={e.id}>
                <td className="px-6 py-3 text-ink">{e.name}</td>
                <td className="px-6 py-3 text-slate">{e.department}</td>
                <td className="px-6 py-3 font-semibold text-ink">{e.overall}</td>
              </tr>
            ))}
            {topAtRisk.length === 0 && (
              <tr>
                <td colSpan={3} className="px-6 py-6 text-center text-slate">
                  Not enough data yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
        <div className="h-2" />
      </Card>
    </div>
  );
}
