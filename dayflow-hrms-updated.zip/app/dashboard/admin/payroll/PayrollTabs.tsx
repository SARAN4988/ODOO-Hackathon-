"use client";

import { useState } from "react";
import { SalaryForm } from "./SalaryForm";
import { PayrollAnomalies } from "./PayrollAnomalies";
import type { PayrollAnomaly } from "@/lib/payrollAnomaly";

export function PayrollTabs({ anomalies }: { anomalies: PayrollAnomaly[] }) {
  const [tab, setTab] = useState<"set" | "anomalies">("set");

  return (
    <div>
      <div className="mb-6 flex gap-2 border-b border-line">
        <button
          onClick={() => setTab("set")}
          className={`border-b-2 px-1 pb-3 text-sm font-medium ${
            tab === "set" ? "border-flow text-flow" : "border-transparent text-slate"
          }`}
        >
          Set Salary
        </button>
        <button
          onClick={() => setTab("anomalies")}
          className={`border-b-2 px-1 pb-3 text-sm font-medium ${
            tab === "anomalies" ? "border-flow text-flow" : "border-transparent text-slate"
          }`}
        >
          Anomaly Detection
          {anomalies.length > 0 && (
            <span className="ml-2 rounded-full bg-bad/10 px-2 py-0.5 text-xs font-medium text-bad">
              {anomalies.length}
            </span>
          )}
        </button>
      </div>

      {tab === "set" && <SalaryForm />}
      {tab === "anomalies" && <PayrollAnomalies anomalies={anomalies} />}
    </div>
  );
}
