import { createClient } from "@/lib/supabase/server";
import {
  detectBandOutliers,
  detectSuddenChanges,
  detectDeductionsExceedPay,
  detectMissingSalary,
  attachNames,
  sortAnomalies,
  type SalaryRow,
  type EmployeeLite,
} from "@/lib/payrollAnomaly";
import { PayrollTabs } from "./PayrollTabs";

export default async function AdminPayrollPage() {
  const supabase = createClient();

  const [{ data: employees }, { data: salaryRows }] = await Promise.all([
    supabase.from("users").select("id, full_name, department, job_title").eq("role", "employee"),
    supabase
      .from("salary_structures")
      .select("user_id, base_salary, allowances, deductions, effective_date")
      .order("effective_date", { ascending: true }),
  ]);

  const employeeList = (employees as EmployeeLite[]) ?? [];
  const rows = (salaryRows as SalaryRow[]) ?? [];
  const deptOf = new Map(employeeList.map((e) => [e.id, e.department]));
  const nameOf = new Map(employeeList.map((e) => [e.id, e.full_name]));

  // Latest salary record per employee (rows are ordered ascending by effective_date).
  const latestByEmployee = new Map<string, SalaryRow>();
  const historyByEmployee = new Map<string, SalaryRow[]>();
  for (const row of rows) {
    latestByEmployee.set(row.user_id, row); // last write wins since ascending order
    const arr = historyByEmployee.get(row.user_id) ?? [];
    arr.push(row);
    historyByEmployee.set(row.user_id, arr);
  }

  const latestWithDept = Array.from(latestByEmployee.values()).map((r) => ({
    ...r,
    department: deptOf.get(r.user_id) ?? null,
  }));

  const anomalies = sortAnomalies(
    attachNames(
      [
        ...detectBandOutliers(latestWithDept),
        ...detectSuddenChanges(historyByEmployee),
        ...detectDeductionsExceedPay(Array.from(latestByEmployee.values())),
        ...detectMissingSalary(employeeList, new Set(latestByEmployee.keys())),
      ],
      nameOf
    )
  );

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Payroll</h1>
      <p className="mt-1 text-sm text-slate">Set salary structures, and keep an eye on anomalies across the org.</p>
      <div className="mt-6">
        <PayrollTabs anomalies={anomalies} />
      </div>
    </div>
  );
}
