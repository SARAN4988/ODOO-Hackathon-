"use client";

import { Card } from "@/components/Card";
import type { PayrollAnomaly } from "@/lib/payrollAnomaly";

const TYPE_LABEL: Record<PayrollAnomaly["type"], string> = {
  "band-outlier": "Outside department band",
  "sudden-change": "Sudden change",
  "no-salary-on-file": "No salary on file",
  "deductions-exceed-pay": "Deductions exceed pay",
};

const SEVERITY_STYLES: Record<PayrollAnomaly["severity"], string> = {
  Critical: "bg-bad/10 text-bad",
  Watch: "bg-warn/10 text-warn",
};

export function PayrollAnomalies({ anomalies }: { anomalies: PayrollAnomaly[] }) {
  const critical = anomalies.filter((a) => a.severity === "Critical").length;

  return (
    <div className="space-y-6">
      <Card>
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Payroll anomaly detection
        </h2>
        <p className="mt-1 text-sm text-slate">
          Rule-based checks: department pay-band outliers (1.75σ+ from the department mean), salary jumps/drops
          of 25%+ between consecutive records, deductions that exceed pay, and employees with no salary
          structure at all. Nothing here is auto-corrected — it's a worklist to review.
        </p>
        <div className="mt-4 flex gap-6 text-sm">
          <div>
            <p className="font-display text-2xl font-semibold text-bad">{critical}</p>
            <p className="text-slate">critical</p>
          </div>
          <div>
            <p className="font-display text-2xl font-semibold text-ink">{anomalies.length}</p>
            <p className="text-slate">total flagged</p>
          </div>
        </div>
      </Card>

      <Card className="!p-0">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-slate">
              <th className="px-6 py-3 font-medium">Employee</th>
              <th className="px-6 py-3 font-medium">Type</th>
              <th className="px-6 py-3 font-medium">Detail</th>
              <th className="px-6 py-3 font-medium">Severity</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {anomalies.map((a) => (
              <tr key={a.id}>
                <td className="px-6 py-3 text-ink">{a.employeeName}</td>
                <td className="px-6 py-3 text-slate">{TYPE_LABEL[a.type]}</td>
                <td className="px-6 py-3 text-slate">{a.detail}</td>
                <td className="px-6 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${SEVERITY_STYLES[a.severity]}`}>
                    {a.severity}
                  </span>
                </td>
              </tr>
            ))}
            {anomalies.length === 0 && (
              <tr>
                <td colSpan={4} className="px-6 py-6 text-center text-slate">
                  No anomalies detected — payroll looks clean.
                </td>
              </tr>
            )}
          </tbody>
        </table>
        <div className="h-2" />
      </Card>
    </div>
  );
}
