import { redirect } from "next/navigation";
import { getUserProfile } from "@/lib/supabase/server";

export default async function DashboardRoot() {
  const { profile } = await getUserProfile();

  if (profile?.role === "admin") redirect("/dashboard/admin");
  redirect("/dashboard/employee");
}
