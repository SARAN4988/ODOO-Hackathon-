import { redirect } from "next/navigation";
import { getUserProfile } from "@/lib/supabase/server";
import { Sidebar } from "@/components/Sidebar";

export default async function EmployeeLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user, profile } = await getUserProfile();
  if (!user || !profile) redirect("/auth/login");

  return (
    <div className="flex">
      <Sidebar role="employee" name={profile.full_name} />
      <main className="min-h-screen flex-1 bg-mist p-8">{children}</main>
    </div>
  );
}
