"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Card } from "@/components/Card";
import { StatusBadge } from "@/components/StatusBadge";
import { Field } from "@/components/AuthShell";

type LeaveRow = {
  id: string;
  leave_type: string;
  start_date: string;
  end_date: string;
  remarks: string | null;
  status: string;
  admin_comment: string | null;
};

export default function LeavePage() {
  const supabase = createClient();
  const [rows, setRows] = useState<LeaveRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({
    leave_type: "paid",
    start_date: "",
    end_date: "",
    remarks: "",
  });

  async function load() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("leave_requests")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    setRows(data ?? []);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (form.end_date < form.start_date) {
      setError("End date can't be before the start date.");
      return;
    }

    setSubmitting(true);
    const {
      data: { user },
    } = await supabase.auth.getUser();

    const { error: insertError } = await supabase.from("leave_requests").insert({
      user_id: user!.id,
      leave_type: form.leave_type,
      start_date: form.start_date,
      end_date: form.end_date,
      remarks: form.remarks || null,
    });

    setSubmitting(false);

    if (insertError) {
      setError(insertError.message);
      return;
    }

    setForm({ leave_type: "paid", start_date: "", end_date: "", remarks: "" });
    load();
  }

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Leave requests</h1>
      <p className="mt-1 text-sm text-slate">Apply for time off and track approval status.</p>

      <Card className="mt-6">
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Apply for leave
        </h2>
        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <Field label="Type">
              <select
                className="input"
                value={form.leave_type}
                onChange={(e) => setForm((f) => ({ ...f, leave_type: e.target.value }))}
              >
                <option value="paid">Paid</option>
                <option value="sick">Sick</option>
                <option value="unpaid">Unpaid</option>
              </select>
            </Field>
            <Field label="Start date">
              <input
                type="date"
                required
                className="input"
                value={form.start_date}
                onChange={(e) => setForm((f) => ({ ...f, start_date: e.target.value }))}
              />
            </Field>
            <Field label="End date">
              <input
                type="date"
                required
                className="input"
                value={form.end_date}
                onChange={(e) => setForm((f) => ({ ...f, end_date: e.target.value }))}
              />
            </Field>
          </div>

          <Field label="Remarks (optional)">
            <textarea
              className="input"
              rows={2}
              value={form.remarks}
              onChange={(e) => setForm((f) => ({ ...f, remarks: e.target.value }))}
              placeholder="Anything HR should know"
            />
          </Field>

          {error && <p className="text-sm text-bad">{error}</p>}

          <button type="submit" disabled={submitting} className="btn-primary">
            {submitting ? "Submitting…" : "Submit request"}
          </button>
        </form>
      </Card>

      <Card className="mt-6">
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Your requests
        </h2>
        {loading ? (
          <p className="mt-3 text-sm text-slate">Loading…</p>
        ) : rows.length === 0 ? (
          <p className="mt-3 text-sm text-slate">No leave requests yet.</p>
        ) : (
          <ul className="mt-3 divide-y divide-line">
            {rows.map((r) => (
              <li key={r.id} className="py-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm capitalize text-ink">
                    {r.leave_type} · {r.start_date} → {r.end_date}
                  </p>
                  <StatusBadge status={r.status} />
                </div>
                {r.remarks && <p className="mt-1 text-xs text-slate">Note: {r.remarks}</p>}
                {r.admin_comment && (
                  <p className="mt-1 text-xs text-slate">HR comment: {r.admin_comment}</p>
                )}
              </li>
            ))}
          </ul>
        )}
      </Card>

      <style jsx global>{`
        .input {
          width: 100%;
          border: 1px solid #e3e6ef;
          border-radius: 10px;
          padding: 0.5rem 0.65rem;
          font-size: 0.875rem;
        }
        .input:focus {
          outline: none;
          border-color: #3355ff;
          box-shadow: 0 0 0 3px #e8ecff;
        }
        .btn-primary {
          background: #3355ff;
          color: white;
          font-weight: 500;
          font-size: 0.875rem;
          border-radius: 10px;
          padding: 0.55rem 1.1rem;
        }
        .btn-primary:disabled {
          opacity: 0.6;
        }
      `}</style>
    </div>
  );
}
