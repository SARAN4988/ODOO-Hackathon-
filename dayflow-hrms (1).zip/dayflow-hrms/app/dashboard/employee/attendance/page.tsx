"use client";

import { useEffect, useState } from "react";
import { format } from "date-fns";
import { createClient } from "@/lib/supabase/client";
import { Card } from "@/components/Card";
import { StatusBadge } from "@/components/StatusBadge";

type AttendanceRow = {
  id: string;
  date: string;
  check_in: string | null;
  check_out: string | null;
  status: string;
};

export default function AttendancePage() {
  const supabase = createClient();
  const [today, setToday] = useState<AttendanceRow | null>(null);
  const [history, setHistory] = useState<AttendanceRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  const todayStr = format(new Date(), "yyyy-MM-dd");

  async function load() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const { data: todayRow } = await supabase
      .from("attendance")
      .select("*")
      .eq("user_id", user.id)
      .eq("date", todayStr)
      .maybeSingle();

    const { data: historyRows } = await supabase
      .from("attendance")
      .select("*")
      .eq("user_id", user.id)
      .order("date", { ascending: false })
      .limit(14);

    setToday(todayRow);
    setHistory(historyRows ?? []);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleCheckIn() {
    setBusy(true);
    const {
      data: { user },
    } = await supabase.auth.getUser();

    await supabase.from("attendance").insert({
      user_id: user!.id,
      date: todayStr,
      check_in: new Date().toISOString(),
      status: "present",
    });

    await load();
    setBusy(false);
  }

  async function handleCheckOut() {
    if (!today) return;
    setBusy(true);

    await supabase
      .from("attendance")
      .update({ check_out: new Date().toISOString() })
      .eq("id", today.id);

    await load();
    setBusy(false);
  }

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Attendance</h1>
      <p className="mt-1 text-sm text-slate">Track today's check-in and your recent history.</p>

      <Card className="mt-6 flex items-center justify-between">
        <div>
          <p className="text-sm text-slate">Today · {format(new Date(), "EEEE, MMM d")}</p>
          <p className="mt-1 text-sm text-ink">
            {today?.check_in
              ? `Checked in at ${format(new Date(today.check_in), "h:mm a")}`
              : "You haven't checked in yet"}
            {today?.check_out &&
              ` · Checked out at ${format(new Date(today.check_out), "h:mm a")}`}
          </p>
        </div>

        {!loading && (
          <button
            onClick={today?.check_in ? handleCheckOut : handleCheckIn}
            disabled={busy || !!today?.check_out}
            className="btn-primary"
          >
            {today?.check_out
              ? "Done for today"
              : today?.check_in
              ? "Check out"
              : "Check in"}
          </button>
        )}
      </Card>

      <Card className="mt-6">
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Last 14 days
        </h2>
        <table className="mt-3 w-full text-left text-sm">
          <thead>
            <tr className="text-xs text-slate">
              <th className="pb-2 font-medium">Date</th>
              <th className="pb-2 font-medium">Check in</th>
              <th className="pb-2 font-medium">Check out</th>
              <th className="pb-2 font-medium">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {history.map((row) => (
              <tr key={row.id}>
                <td className="py-2 text-ink">{row.date}</td>
                <td className="py-2 text-slate">
                  {row.check_in ? format(new Date(row.check_in), "h:mm a") : "—"}
                </td>
                <td className="py-2 text-slate">
                  {row.check_out ? format(new Date(row.check_out), "h:mm a") : "—"}
                </td>
                <td className="py-2">
                  <StatusBadge status={row.status} />
                </td>
              </tr>
            ))}
            {history.length === 0 && (
              <tr>
                <td colSpan={4} className="py-4 text-center text-slate">
                  No attendance recorded yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Card>

      <style jsx global>{`
        .btn-primary {
          background: #3355ff;
          color: white;
          font-weight: 500;
          font-size: 0.875rem;
          border-radius: 10px;
          padding: 0.55rem 1.1rem;
        }
        .btn-primary:disabled {
          opacity: 0.5;
        }
      `}</style>
    </div>
  );
}
