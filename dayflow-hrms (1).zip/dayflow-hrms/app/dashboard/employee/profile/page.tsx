import Link from "next/link";
import { getUserProfile } from "@/lib/supabase/server";
import { Card } from "@/components/Card";

export default async function ProfilePage() {
  const { profile } = await getUserProfile();
  if (!profile) return null;

  return (
    <div className="mx-auto max-w-3xl">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold text-ink">Profile</h1>
        <Link href="/dashboard/employee/profile/edit" className="btn-primary">
          Edit profile
        </Link>
      </div>

      <Card className="mt-6">
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Personal details
        </h2>
        <dl className="mt-3 grid grid-cols-2 gap-4 text-sm">
          <Info label="Full name" value={profile.full_name} />
          <Info label="Employee ID" value={profile.employee_id} />
          <Info label="Email" value={profile.email} />
          <Info label="Phone" value={profile.phone ?? "—"} />
          <Info label="Address" value={profile.address ?? "—"} />
        </dl>
      </Card>

      <Card className="mt-6">
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Job details
        </h2>
        <dl className="mt-3 grid grid-cols-2 gap-4 text-sm">
          <Info label="Job title" value={profile.job_title ?? "—"} />
          <Info label="Department" value={profile.department ?? "—"} />
          <Info label="Date joined" value={profile.date_joined ?? "—"} />
        </dl>
      </Card>

      <style>{`
        .btn-primary {
          background: #3355FF; color: white; font-weight: 500; font-size: 0.875rem;
          border-radius: 10px; padding: 0.5rem 1rem;
        }
      `}</style>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs text-slate">{label}</dt>
      <dd className="mt-0.5 text-ink">{value}</dd>
    </div>
  );
}
