import Link from "next/link";
import { createClient, getUserProfile } from "@/lib/supabase/server";
import { Card } from "@/components/Card";
import { StatusBadge } from "@/components/StatusBadge";

export default async function EmployeeOverview() {
  const { user, profile } = await getUserProfile();
  const supabase = createClient();

  const { data: recentLeave } = await supabase
    .from("leave_requests")
    .select("id, leave_type, start_date, end_date, status")
    .eq("user_id", user!.id)
    .order("created_at", { ascending: false })
    .limit(3);

  const { data: todayAttendance } = await supabase
    .from("attendance")
    .select("check_in, check_out, status")
    .eq("user_id", user!.id)
    .eq("date", new Date().toISOString().slice(0, 10))
    .maybeSingle();

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="font-display text-2xl font-semibold text-ink">
        Welcome back, {profile?.full_name?.split(" ")[0]}
      </h1>
      <p className="mt-1 text-sm text-slate">Here's where things stand today.</p>

      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <QuickCard href="/dashboard/employee/profile" title="Profile" subtitle="View & edit" />
        <QuickCard
          href="/dashboard/employee/attendance"
          title="Attendance"
          subtitle={todayAttendance ? "Checked in today" : "Not checked in yet"}
        />
        <QuickCard href="/dashboard/employee/leave" title="Leave requests" subtitle="Apply or track" />
        <QuickCard href="/dashboard/employee/payroll" title="Payroll" subtitle="View salary" />
      </div>

      <Card className="mt-6">
        <h2 className="font-display text-base font-semibold text-ink">
          Recent leave activity
        </h2>
        {!recentLeave || recentLeave.length === 0 ? (
          <p className="mt-3 text-sm text-slate">No leave requests yet.</p>
        ) : (
          <ul className="mt-3 divide-y divide-line">
            {recentLeave.map((r) => (
              <li key={r.id} className="flex items-center justify-between py-3 text-sm">
                <span className="capitalize text-ink">
                  {r.leave_type} · {r.start_date} → {r.end_date}
                </span>
                <StatusBadge status={r.status} />
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function QuickCard({
  href,
  title,
  subtitle,
}: {
  href: string;
  title: string;
  subtitle: string;
}) {
  return (
    <Link href={href}>
      <Card className="transition-shadow hover:shadow-lg">
        <p className="font-display font-semibold text-ink">{title}</p>
        <p className="mt-1 text-sm text-slate">{subtitle}</p>
      </Card>
    </Link>
  );
}
