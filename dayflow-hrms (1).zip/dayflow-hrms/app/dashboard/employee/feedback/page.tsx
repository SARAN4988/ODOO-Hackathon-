"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Card } from "@/components/Card";
import { Field } from "@/components/AuthShell";
import { clsx } from "clsx";

type FeedbackRow = { id: string; category: string; rating: number; comment: string | null; is_anonymous: boolean; created_at: string };

const CATEGORIES = ["Work environment", "Management", "Workload", "Growth", "Compensation", "Other"];

export default function EmployeeFeedbackPage() {
  const supabase = createClient();
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [rating, setRating] = useState(4);
  const [comment, setComment] = useState("");
  const [anonymous, setAnonymous] = useState(false);
  const [saving, setSaving] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [mine, setMine] = useState<FeedbackRow[]>([]);

  async function load() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;
    const { data } = await supabase
      .from("feedback")
      .select("id, category, rating, comment, is_anonymous, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });
    setMine((data as any) ?? []);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setSubmitted(false);
    const {
      data: { user },
    } = await supabase.auth.getUser();
    await supabase.from("feedback").insert({
      user_id: user?.id,
      category,
      rating,
      comment: comment.trim() || null,
      is_anonymous: anonymous,
    });
    setSaving(false);
    setSubmitted(true);
    setComment("");
    setRating(4);
    setAnonymous(false);
    load();
  }

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Feedback</h1>
      <p className="mt-1 text-sm text-slate">
        Tell HR how things are going. Mark it anonymous if you'd rather your name not show up next to it.
      </p>

      <Card className="mt-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="What's this about?">
            <select className="input" value={category} onChange={(e) => setCategory(e.target.value)}>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </Field>

          <Field label={`Rating: ${rating}/5`}>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  type="button"
                  key={n}
                  onClick={() => setRating(n)}
                  className={clsx(
                    "h-9 w-9 rounded-lg border text-sm font-medium",
                    rating === n ? "border-flow bg-flow-light text-flow-dark" : "border-line text-slate"
                  )}
                >
                  {n}
                </button>
              ))}
            </div>
          </Field>

          <Field label="Comments (optional)">
            <textarea
              className="input"
              rows={4}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="What's working, what isn't…"
            />
          </Field>

          <label className="flex items-center gap-2 text-sm text-slate">
            <input type="checkbox" checked={anonymous} onChange={(e) => setAnonymous(e.target.checked)} />
            Submit anonymously
          </label>

          {submitted && <p className="text-sm text-ok">Thanks — your feedback was submitted.</p>}

          <button type="submit" disabled={saving} className="btn-primary">
            {saving ? "Submitting…" : "Submit feedback"}
          </button>
        </form>
      </Card>

      <Card className="mt-6 !p-0">
        <div className="p-6 pb-0">
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">Your history</h2>
        </div>
        <ul className="mt-3 divide-y divide-line">
          {mine.map((f) => (
            <li key={f.id} className="px-6 py-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="font-medium text-ink">
                  {f.category} · {f.rating}/5 {f.is_anonymous && <span className="text-xs text-slate">(anonymous)</span>}
                </span>
                <span className="text-xs text-slate">{new Date(f.created_at).toLocaleDateString()}</span>
              </div>
              {f.comment && <p className="mt-1 text-slate">{f.comment}</p>}
            </li>
          ))}
          {mine.length === 0 && <li className="px-6 py-6 text-center text-sm text-slate">No feedback submitted yet.</li>}
        </ul>
        <div className="h-2" />
      </Card>

      <style jsx global>{`
        .input {
          width: 100%;
          border: 1px solid #e3e6ef;
          border-radius: 10px;
          padding: 0.5rem 0.65rem;
          font-size: 0.875rem;
          background: white;
        }
        .input:focus {
          outline: none;
          border-color: #3355ff;
          box-shadow: 0 0 0 3px #e8ecff;
        }
        .btn-primary {
          background: #3355ff;
          color: white;
          font-weight: 500;
          font-size: 0.875rem;
          border-radius: 10px;
          padding: 0.55rem 1.1rem;
        }
        .btn-primary:disabled {
          opacity: 0.6;
        }
      `}</style>
    </div>
  );
}
