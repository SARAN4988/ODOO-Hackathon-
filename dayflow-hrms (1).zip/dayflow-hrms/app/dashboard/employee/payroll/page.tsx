import { createClient, getUserProfile } from "@/lib/supabase/server";
import { Card } from "@/components/Card";

export default async function PayrollPage() {
  const { user } = await getUserProfile();
  const supabase = createClient();

  const { data: salary } = await supabase
    .from("salary_structures")
    .select("*")
    .eq("user_id", user!.id)
    .order("effective_date", { ascending: false })
    .limit(1)
    .maybeSingle();

  const allowances = (salary?.allowances ?? {}) as Record<string, number>;
  const deductions = (salary?.deductions ?? {}) as Record<string, number>;

  const totalAllowances = Object.values(allowances).reduce((a, b) => a + b, 0);
  const totalDeductions = Object.values(deductions).reduce((a, b) => a + b, 0);
  const net = (salary?.base_salary ?? 0) + totalAllowances - totalDeductions;

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Payroll</h1>
      <p className="mt-1 text-sm text-slate">
        This is read-only. Reach out to HR for any corrections.
      </p>

      {!salary ? (
        <Card className="mt-6">
          <p className="text-sm text-slate">
            No salary structure has been set up for you yet. Contact HR.
          </p>
        </Card>
      ) : (
        <Card className="mt-6">
          <div className="flex items-baseline justify-between">
            <p className="text-sm text-slate">Net monthly pay</p>
            <p className="font-display text-3xl font-semibold text-ink">
              ${net.toLocaleString()}
            </p>
          </div>

          <div className="mt-6 space-y-3 border-t border-line pt-4 text-sm">
            <Row label="Base salary" value={salary.base_salary} />
            {Object.entries(allowances).map(([key, value]) => (
              <Row key={key} label={`+ ${key}`} value={value} />
            ))}
            {Object.entries(deductions).map(([key, value]) => (
              <Row key={key} label={`− ${key}`} value={-value} />
            ))}
          </div>

          <p className="mt-4 text-xs text-slate">
            Effective from {salary.effective_date}
          </p>
        </Card>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex justify-between">
      <span className="capitalize text-slate">{label}</span>
      <span className="text-ink">
        {value < 0 ? "-" : ""}${Math.abs(value).toLocaleString()}
      </span>
    </div>
  );
}
