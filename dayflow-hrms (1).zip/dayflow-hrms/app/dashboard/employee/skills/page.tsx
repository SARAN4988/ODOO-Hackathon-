"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Card } from "@/components/Card";
import { Field } from "@/components/AuthShell";
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Tooltip,
} from "recharts";

type Skill = { id: string; skill_name: string; category: string; proficiency: number };

const CATEGORIES = ["Technical", "Communication", "Leadership", "Domain", "Tools", "General"];

export default function EmployeeSkillsPage() {
  const supabase = createClient();
  const [skills, setSkills] = useState<Skill[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("");
  const [category, setCategory] = useState("Technical");
  const [proficiency, setProficiency] = useState(3);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  async function load() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;
    const { data } = await supabase
      .from("skills")
      .select("id, skill_name, category, proficiency")
      .eq("user_id", user.id)
      .order("skill_name");
    setSkills((data as any) ?? []);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!name.trim()) return;
    setSaving(true);
    const {
      data: { user },
    } = await supabase.auth.getUser();
    const { error: upsertError } = await supabase
      .from("skills")
      .upsert(
        { user_id: user?.id, skill_name: name.trim(), category, proficiency },
        { onConflict: "user_id,skill_name" }
      );
    setSaving(false);
    if (upsertError) {
      setError("Couldn't save that skill — try again.");
      return;
    }
    setName("");
    setProficiency(3);
    load();
  }

  async function handleRemove(id: string) {
    await supabase.from("skills").delete().eq("id", id);
    load();
  }

  const radarData = skills.map((s) => ({ skill: s.skill_name, proficiency: s.proficiency }));

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-display text-2xl font-semibold text-ink">My Skills</h1>
      <p className="mt-1 text-sm text-slate">
        Keep this up to date — HR uses it to spot coverage gaps and match people to work.
      </p>

      <Card className="mt-6">
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">Add or update a skill</h2>
        <form onSubmit={handleAdd} className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-4 sm:items-end">
          <div className="sm:col-span-2">
            <Field label="Skill">
              <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. React" />
            </Field>
          </div>
          <Field label="Category">
            <select className="input" value={category} onChange={(e) => setCategory(e.target.value)}>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </Field>
          <Field label={`Proficiency: ${proficiency}/5`}>
            <input
              type="range"
              min={1}
              max={5}
              value={proficiency}
              onChange={(e) => setProficiency(Number(e.target.value))}
              className="w-full"
            />
          </Field>
          <div className="sm:col-span-4">
            <button type="submit" disabled={saving} className="btn-primary">
              {saving ? "Saving…" : "Save skill"}
            </button>
            {error && <span className="ml-3 text-sm text-bad">{error}</span>}
          </div>
        </form>
      </Card>

      <Card className="mt-6">
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">Your skill radar</h2>
        <div className="mt-4 h-72">
          {loading ? (
            <p className="text-sm text-slate">Loading…</p>
          ) : radarData.length === 0 ? (
            <p className="flex h-full items-center justify-center text-sm text-slate">Add a few skills to see your radar.</p>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData} outerRadius={100}>
                <PolarGrid stroke="#E3E6EF" />
                <PolarAngleAxis dataKey="skill" tick={{ fontSize: 12, fill: "#4B5468" }} />
                <PolarRadiusAxis domain={[0, 5]} tick={{ fontSize: 10, fill: "#4B5468" }} />
                <Radar dataKey="proficiency" stroke="#3355FF" fill="#3355FF" fillOpacity={0.25} />
                <Tooltip />
              </RadarChart>
            </ResponsiveContainer>
          )}
        </div>
      </Card>

      <Card className="mt-6 !p-0">
        <ul className="divide-y divide-line">
          {skills.map((s) => (
            <li key={s.id} className="flex items-center justify-between px-6 py-3 text-sm">
              <div>
                <span className="text-ink">{s.skill_name}</span>
                <span className="ml-2 text-xs text-slate">{s.category} · {s.proficiency}/5</span>
              </div>
              <button onClick={() => handleRemove(s.id)} className="text-xs font-medium text-bad">
                Remove
              </button>
            </li>
          ))}
          {skills.length === 0 && !loading && (
            <li className="px-6 py-6 text-center text-sm text-slate">No skills added yet.</li>
          )}
        </ul>
      </Card>

      <style jsx global>{`
        .input {
          width: 100%;
          border: 1px solid #e3e6ef;
          border-radius: 10px;
          padding: 0.5rem 0.65rem;
          font-size: 0.875rem;
          background: white;
        }
        .input:focus {
          outline: none;
          border-color: #3355ff;
          box-shadow: 0 0 0 3px #e8ecff;
        }
        .btn-primary {
          background: #3355ff;
          color: white;
          font-weight: 500;
          font-size: 0.875rem;
          border-radius: 10px;
          padding: 0.55rem 1.1rem;
        }
        .btn-primary:disabled {
          opacity: 0.6;
        }
      `}</style>
    </div>
  );
}
