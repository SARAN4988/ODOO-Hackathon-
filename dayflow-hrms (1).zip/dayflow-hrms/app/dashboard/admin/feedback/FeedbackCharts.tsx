"use client";

import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, LineChart, Line } from "recharts";
import { Card } from "@/components/Card";

export type FeedbackComment = {
  id: string;
  category: string;
  rating: number;
  comment: string | null;
  created_at: string;
  authorLabel: string;
};

export function FeedbackCharts({
  avgByCategory,
  monthlyTrend,
  comments,
  overallAvg,
}: {
  avgByCategory: { category: string; avg: number }[];
  monthlyTrend: { month: string; avg: number; count: number }[];
  comments: FeedbackComment[];
  overallAvg: number | null;
}) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        <Card>
          <p className="text-xs text-slate">Overall average rating</p>
          <p className="mt-1 font-display text-2xl font-semibold text-ink">
            {overallAvg != null ? overallAvg.toFixed(1) + " / 5" : "—"}
          </p>
        </Card>
        <Card>
          <p className="text-xs text-slate">Total responses</p>
          <p className="mt-1 font-display text-2xl font-semibold text-ink">{comments.length}</p>
        </Card>
        <Card>
          <p className="text-xs text-slate">Categories tracked</p>
          <p className="mt-1 font-display text-2xl font-semibold text-ink">{avgByCategory.length}</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
            Average rating by category
          </h2>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={avgByCategory}>
                <CartesianGrid stroke="#E3E6EF" vertical={false} />
                <XAxis dataKey="category" tick={{ fontSize: 10, fill: "#4B5468" }} interval={0} angle={-15} textAnchor="end" height={50} />
                <YAxis domain={[0, 5]} tick={{ fontSize: 11, fill: "#4B5468" }} width={28} />
                <Tooltip />
                <Bar dataKey="avg" fill="#3355FF" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
            Rating trend by month
          </h2>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthlyTrend}>
                <CartesianGrid stroke="#E3E6EF" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#4B5468" }} />
                <YAxis domain={[0, 5]} tick={{ fontSize: 11, fill: "#4B5468" }} width={28} />
                <Tooltip />
                <Line type="monotone" dataKey="avg" stroke="#1E9E6C" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <Card className="!p-0">
        <div className="p-6 pb-0">
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">Recent responses</h2>
        </div>
        <ul className="mt-3 divide-y divide-line">
          {comments.slice(0, 15).map((c) => (
            <li key={c.id} className="px-6 py-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="font-medium text-ink">
                  {c.authorLabel} · {c.category} · {c.rating}/5
                </span>
                <span className="text-xs text-slate">{new Date(c.created_at).toLocaleDateString()}</span>
              </div>
              {c.comment && <p className="mt-1 text-slate">{c.comment}</p>}
            </li>
          ))}
          {comments.length === 0 && <li className="px-6 py-6 text-center text-sm text-slate">No feedback submitted yet.</li>}
        </ul>
        <div className="h-2" />
      </Card>
    </div>
  );
}
