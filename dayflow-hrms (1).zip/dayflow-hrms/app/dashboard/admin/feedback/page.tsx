import { createClient } from "@/lib/supabase/server";
import { FeedbackCharts, type FeedbackComment } from "./FeedbackCharts";
import { average, monthKey, monthLabel } from "@/lib/analytics";

export default async function AdminFeedbackPage() {
  const supabase = createClient();
  const { data: rows } = await supabase
    .from("feedback")
    .select("id, category, rating, comment, is_anonymous, created_at, users(full_name)")
    .order("created_at", { ascending: false });

  const feedback = (rows ?? []) as any[];

  const comments: FeedbackComment[] = feedback.map((f) => ({
    id: f.id,
    category: f.category,
    rating: f.rating,
    comment: f.comment,
    created_at: f.created_at,
    authorLabel: f.is_anonymous ? "Anonymous" : f.users?.full_name || "Unknown",
  }));

  const overallAvg = feedback.length ? average(feedback.map((f) => f.rating)) : null;

  const catMap = new Map<string, number[]>();
  for (const f of feedback) {
    const arr = catMap.get(f.category) ?? [];
    arr.push(f.rating);
    catMap.set(f.category, arr);
  }
  const avgByCategory = Array.from(catMap, ([category, ratings]) => ({
    category,
    avg: Math.round(average(ratings) * 10) / 10,
  }));

  const monthMap = new Map<string, number[]>();
  for (const f of feedback) {
    const key = monthKey(f.created_at);
    const arr = monthMap.get(key) ?? [];
    arr.push(f.rating);
    monthMap.set(key, arr);
  }
  const monthlyTrend = Array.from(monthMap, ([key, ratings]) => ({
    month: monthLabel(key),
    avg: Math.round(average(ratings) * 10) / 10,
    count: ratings.length,
    sortKey: key,
  }))
    .sort((a, b) => a.sortKey.localeCompare(b.sortKey))
    .slice(-6);

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Employee Feedback</h1>
      <p className="mt-1 text-sm text-slate">
        Aggregated sentiment across the org. Names are hidden for anything submitted anonymously.
      </p>
      <div className="mt-6">
        <FeedbackCharts avgByCategory={avgByCategory} monthlyTrend={monthlyTrend} comments={comments} overallAvg={overallAvg} />
      </div>
    </div>
  );
}
