import { createClient } from "@/lib/supabase/server";
import { MonitoringView, type LiveAttendanceRow, type LiveEmployee } from "./MonitoringView";

function toDateStr(d: Date) {
  return d.toISOString().slice(0, 10);
}

export default async function MonitoringPage() {
  const supabase = createClient();
  const today = toDateStr(new Date());

  const [{ data: employees }, { data: attendance }, { data: leaves }] = await Promise.all([
    supabase
      .from("users")
      .select("id, full_name, department, job_title")
      .eq("role", "employee")
      .order("full_name"),
    supabase
      .from("attendance")
      .select("user_id, date, check_in, check_out, status")
      .eq("date", today),
    supabase
      .from("leave_requests")
      .select("user_id, start_date, end_date, status")
      .eq("status", "approved")
      .lte("start_date", today)
      .gte("end_date", today),
  ]);

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Real-Time Workforce Monitoring</h1>
      <p className="mt-1 text-sm text-slate">
        A live view of who&apos;s working right now. Updates instantly as people check in and out — no
        refresh needed.
      </p>
      <div className="mt-6">
        <MonitoringView
          employees={(employees as LiveEmployee[]) ?? []}
          initialAttendance={(attendance as LiveAttendanceRow[]) ?? []}
          onLeaveUserIds={((leaves as { user_id: string }[]) ?? []).map((l) => l.user_id)}
          today={today}
        />
      </div>
    </div>
  );
}
