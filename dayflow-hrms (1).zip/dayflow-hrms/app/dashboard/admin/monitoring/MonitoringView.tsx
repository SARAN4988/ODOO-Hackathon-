"use client";

import { useEffect, useMemo, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Card } from "@/components/Card";
import { StatusBadge } from "@/components/StatusBadge";
import { createClient } from "@/lib/supabase/client";

export type LiveEmployee = { id: string; full_name: string; department: string | null; job_title: string | null };
export type LiveAttendanceRow = {
  user_id: string;
  date: string;
  check_in: string | null;
  check_out: string | null;
  status: string;
};

function elapsed(checkIn: string, now: Date) {
  const start = new Date(checkIn).getTime();
  const ms = Math.max(0, now.getTime() - start);
  const totalMinutes = Math.floor(ms / 60000);
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  return `${h}h ${m}m`;
}

export function MonitoringView({
  employees,
  initialAttendance,
  onLeaveUserIds,
  today,
}: {
  employees: LiveEmployee[];
  initialAttendance: LiveAttendanceRow[];
  onLeaveUserIds: string[];
  today: string;
}) {
  const [attendance, setAttendance] = useState<LiveAttendanceRow[]>(initialAttendance);
  const [now, setNow] = useState(new Date());
  const [lastEvent, setLastEvent] = useState<Date | null>(null);
  const [connected, setConnected] = useState(false);

  // Tick every 30s so "elapsed" durations stay fresh without a full refetch.
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30_000);
    return () => clearInterval(t);
  }, []);

  // Supabase Realtime: any insert/update on today's attendance rows lands here
  // instantly, so the board reflects check-ins/check-outs as they happen —
  // no polling, no manual refresh.
  //
  // Note: this requires the `attendance` table to be added to the
  // `supabase_realtime` publication (see supabase/migrations_003_realtime.sql).
  useEffect(() => {
    const supabase = createClient();
    const channel = supabase
      .channel("attendance-live")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "attendance", filter: `date=eq.${today}` },
        (payload) => {
          setLastEvent(new Date());
          setAttendance((prev) => {
            const row = payload.new as LiveAttendanceRow;
            if (payload.eventType === "DELETE") {
              const old = payload.old as Partial<LiveAttendanceRow>;
              return prev.filter((r) => r.user_id !== old.user_id);
            }
            const idx = prev.findIndex((r) => r.user_id === row.user_id);
            if (idx === -1) return [...prev, row];
            const next = [...prev];
            next[idx] = row;
            return next;
          });
        }
      )
      .subscribe((status) => setConnected(status === "SUBSCRIBED"));

    return () => {
      supabase.removeChannel(channel);
    };
  }, [today]);

  const byUser = useMemo(() => new Map(attendance.map((a) => [a.user_id, a])), [attendance]);
  const onLeaveSet = useMemo(() => new Set(onLeaveUserIds), [onLeaveUserIds]);

  const rows = employees.map((e) => {
    const a = byUser.get(e.id);
    const onLeave = onLeaveSet.has(e.id);
    let status: "working" | "checked_out" | "on_leave" | "absent" | "not_checked_in" = "not_checked_in";
    if (onLeave) status = "on_leave";
    else if (a?.status === "absent") status = "absent";
    else if (a?.check_in && !a.check_out) status = "working";
    else if (a?.check_in && a.check_out) status = "checked_out";
    return { employee: e, attendance: a, status };
  });

  const working = rows.filter((r) => r.status === "working");
  const checkedOut = rows.filter((r) => r.status === "checked_out");
  const onLeave = rows.filter((r) => r.status === "on_leave");
  const absent = rows.filter((r) => r.status === "absent");
  const notYet = rows.filter((r) => r.status === "not_checked_in");

  const deptCounts = new Map<string, { working: number; total: number }>();
  for (const r of rows) {
    const dept = r.employee.department || "Unassigned";
    const entry = deptCounts.get(dept) ?? { working: 0, total: 0 };
    entry.total += 1;
    if (r.status === "working") entry.working += 1;
    deptCounts.set(dept, entry);
  }
  const deptChartData = Array.from(deptCounts.entries()).map(([department, v]) => ({
    department,
    "Working now": v.working,
    "Rest of team": v.total - v.working,
  }));

  const kpis = [
    { label: "Working now", value: working.length, tone: "text-ok" },
    { label: "Checked out", value: checkedOut.length, tone: "text-slate" },
    { label: "On leave", value: onLeave.length, tone: "text-flow" },
    { label: "Absent", value: absent.length, tone: "text-bad" },
    { label: "Not checked in yet", value: notYet.length, tone: "text-warn" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 text-xs text-slate">
        <span
          className={`h-2 w-2 rounded-full ${connected ? "animate-pulse bg-ok" : "bg-line"}`}
          aria-hidden
        />
        <span>{connected ? "Live" : "Connecting…"}</span>
        <span>·</span>
        <span>Last event: {lastEvent ? lastEvent.toLocaleTimeString() : "none yet this session"}</span>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-5">
        {kpis.map((k) => (
          <Card key={k.label} className="text-center">
            <p className={`font-display text-3xl font-semibold ${k.tone}`}>{k.value}</p>
            <p className="mt-1 text-xs text-slate">{k.label}</p>
          </Card>
        ))}
      </div>

      <Card>
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Coverage by department, right now
        </h2>
        <div className="mt-4 h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={deptChartData} layout="vertical" margin={{ left: 24 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E3E6EF" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11, fill: "#4B5468" }} allowDecimals={false} />
              <YAxis type="category" dataKey="department" tick={{ fontSize: 12, fill: "#4B5468" }} width={110} />
              <Tooltip />
              <Bar dataKey="Working now" stackId="a" fill="#1E9E6C" radius={[0, 4, 4, 0]} />
              <Bar dataKey="Rest of team" stackId="a" fill="#E3E6EF" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card className="!p-0">
        <div className="p-6 pb-0">
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
            Currently working ({working.length})
          </h2>
        </div>
        <table className="mt-4 w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-slate">
              <th className="px-6 py-3 font-medium">Name</th>
              <th className="px-6 py-3 font-medium">Department</th>
              <th className="px-6 py-3 font-medium">Checked in</th>
              <th className="px-6 py-3 font-medium">Time on the clock</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {working.map((r) => (
              <tr key={r.employee.id}>
                <td className="px-6 py-3 text-ink">{r.employee.full_name}</td>
                <td className="px-6 py-3 text-slate">{r.employee.department ?? "—"}</td>
                <td className="px-6 py-3 text-slate">
                  {r.attendance?.check_in ? new Date(r.attendance.check_in).toLocaleTimeString() : "—"}
                </td>
                <td className="px-6 py-3 font-medium text-ok">
                  {r.attendance?.check_in ? elapsed(r.attendance.check_in, now) : "—"}
                </td>
              </tr>
            ))}
            {working.length === 0 && (
              <tr>
                <td colSpan={4} className="px-6 py-6 text-center text-sm text-slate">
                  Nobody is checked in right now.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Card>

      <Card className="!p-0">
        <div className="p-6 pb-0">
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
            Everyone else today
          </h2>
        </div>
        <table className="mt-4 w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-slate">
              <th className="px-6 py-3 font-medium">Name</th>
              <th className="px-6 py-3 font-medium">Department</th>
              <th className="px-6 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {rows
              .filter((r) => r.status !== "working")
              .map((r) => (
                <tr key={r.employee.id}>
                  <td className="px-6 py-3 text-ink">{r.employee.full_name}</td>
                  <td className="px-6 py-3 text-slate">{r.employee.department ?? "—"}</td>
                  <td className="px-6 py-3">
                    <StatusBadge
                      status={
                        r.status === "not_checked_in"
                          ? "pending"
                          : r.status === "on_leave"
                          ? "leave"
                          : r.status === "checked_out"
                          ? "present"
                          : "absent"
                      }
                    />
                    {r.status === "not_checked_in" && (
                      <span className="ml-2 text-xs text-slate">not checked in yet</span>
                    )}
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
