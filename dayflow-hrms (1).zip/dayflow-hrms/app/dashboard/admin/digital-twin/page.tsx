import { createClient } from "@/lib/supabase/server";
import { buildRiskProfile } from "@/lib/analytics";
import { buildDepartmentSnapshots } from "@/lib/digitalTwin";
import { DigitalTwinView } from "./DigitalTwinView";

export default async function DigitalTwinPage() {
  const supabase = createClient();
  const cutoff30 = new Date();
  cutoff30.setDate(cutoff30.getDate() - 30);
  const cutoff90 = new Date();
  cutoff90.setDate(cutoff90.getDate() - 90);
  const cutoff12mo = new Date();
  cutoff12mo.setMonth(cutoff12mo.getMonth() - 12);

  const [{ data: users }, { data: attendance90 }, { data: leaves }, { data: feedback }, { data: salaries }] =
    await Promise.all([
      supabase.from("users").select("id, full_name, department, date_joined").eq("role", "employee"),
      supabase
        .from("attendance")
        .select("user_id, date, status")
        .gte("date", cutoff90.toISOString().slice(0, 10)),
      supabase
        .from("leave_requests")
        .select("user_id, start_date, end_date, status")
        .gte("created_at", cutoff12mo.toISOString()),
      supabase.from("feedback").select("user_id, rating"),
      supabase
        .from("salary_structures")
        .select("user_id, base_salary, allowances, effective_date")
        .order("effective_date", { ascending: false }),
    ]);

  const employees = (users ?? []) as { id: string; full_name: string; department: string | null; date_joined: string | null }[];

  const attendanceByUser = new Map<string, { date: string; status: string }[]>();
  for (const a of (attendance90 ?? []) as any[]) {
    const arr = attendanceByUser.get(a.user_id) ?? [];
    arr.push(a);
    attendanceByUser.set(a.user_id, arr);
  }
  const attendance30ByUser = new Map<string, { date: string; status: string }[]>();
  const cutoff30Str = cutoff30.toISOString().slice(0, 10);
  for (const [uid, rows] of attendanceByUser) {
    attendance30ByUser.set(
      uid,
      rows.filter((r) => r.date >= cutoff30Str)
    );
  }

  const leavesByUser = new Map<string, any[]>();
  for (const l of (leaves ?? []) as any[]) {
    const arr = leavesByUser.get(l.user_id) ?? [];
    arr.push(l);
    leavesByUser.set(l.user_id, arr);
  }
  const feedbackByUser = new Map<string, number[]>();
  for (const f of (feedback ?? []) as any[]) {
    const arr = feedbackByUser.get(f.user_id) ?? [];
    arr.push(f.rating);
    feedbackByUser.set(f.user_id, arr);
  }
  // Most-recent salary row per user (list is already ordered by effective_date desc).
  const costByUser = new Map<string, number>();
  for (const s of (salaries ?? []) as any[]) {
    if (costByUser.has(s.user_id)) continue;
    const allowanceTotal = s.allowances
      ? Object.values(s.allowances as Record<string, number>).reduce((a: number, b: any) => a + Number(b || 0), 0)
      : 0;
    costByUser.set(s.user_id, Number(s.base_salary || 0) + allowanceTotal);
  }

  const riskByUser = new Map<string, number>();
  for (const e of employees) {
    const ratings = feedbackByUser.get(e.id) ?? [];
    const avgFeedbackRating = ratings.length ? ratings.reduce((a, b) => a + b, 0) / ratings.length : null;
    const { overall } = buildRiskProfile({
      attendance: attendanceByUser.get(e.id) ?? [],
      leaves: leavesByUser.get(e.id) ?? [],
      avgFeedbackRating,
      dateJoined: e.date_joined,
    });
    riskByUser.set(e.id, overall);
  }

  const snapshots = buildDepartmentSnapshots({
    employees,
    attendanceByUser: attendance30ByUser,
    monthlyCostByUser: costByUser,
    riskByUser,
  });

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-display text-2xl font-semibold text-ink">AI Workforce Digital Twin</h1>
      <p className="mt-1 text-sm text-slate">
        A live model of your org, built from the last 30 days of real attendance, payroll and risk data.
        Pull the levers below to see how a shock, a leave surge, an exit, or a hire would ripple through
        coverage, cost and risk — before it happens.
      </p>
      <div className="mt-6">
        <DigitalTwinView snapshots={snapshots} />
      </div>
    </div>
  );
}
