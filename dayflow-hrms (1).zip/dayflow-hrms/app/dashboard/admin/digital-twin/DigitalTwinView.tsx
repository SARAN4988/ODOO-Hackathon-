"use client";

import { useMemo, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Card } from "@/components/Card";
import { clsx } from "clsx";
import { simulateScenario, type DeptSnapshot, type ScenarioResult } from "@/lib/digitalTwin";

const VERDICT_STYLE: Record<ScenarioResult["coverageVerdict"], string> = {
  Healthy: "bg-ok/10 text-ok",
  Tight: "bg-warn/10 text-warn",
  "At risk": "bg-bad/10 text-bad",
};

function currency(n: number) {
  return n.toLocaleString(undefined, { maximumFractionDigits: 0 });
}

export function DigitalTwinView({ snapshots }: { snapshots: DeptSnapshot[] }) {
  const departments = snapshots.map((s) => s.department);
  const [target, setTarget] = useState<string>("__all__");
  const [attendanceShock, setAttendanceShock] = useState(0);
  const [leaveSurge, setLeaveSurge] = useState(0);
  const [attrition, setAttrition] = useState(0);
  const [newHires, setNewHires] = useState(0);

  const results = useMemo(
    () =>
      simulateScenario(snapshots, {
        attendanceShockPct: attendanceShock,
        leaveSurgePct: leaveSurge,
        attritionCount: attrition,
        newHires,
        targetDepartment: target === "__all__" ? null : target,
      }),
    [snapshots, attendanceShock, leaveSurge, attrition, newHires, target]
  );

  const totals = results.reduce(
    (acc, r) => ({
      headcount: acc.headcount + r.headcount,
      projectedHeadcount: acc.projectedHeadcount + r.projectedHeadcount,
      cost: acc.cost + r.headcount * r.avgMonthlyCost,
      projectedCost: acc.projectedCost + r.projectedMonthlyCost,
    }),
    { headcount: 0, projectedHeadcount: 0, cost: 0, projectedCost: 0 }
  );

  const chartData = results.map((r) => ({
    department: r.department,
    "Current coverage": r.presentRate,
    "Projected coverage": r.projectedPresentRate,
  }));

  const resetScenario = () => {
    setAttendanceShock(0);
    setLeaveSurge(0);
    setAttrition(0);
    setNewHires(0);
    setTarget("__all__");
  };

  return (
    <div className="space-y-6">
      <Card>
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Current state (live)
        </h2>
        <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
          <div>
            <p className="font-display text-2xl font-semibold text-ink">{totals.headcount}</p>
            <p className="text-xs text-slate">Employees modeled</p>
          </div>
          <div>
            <p className="font-display text-2xl font-semibold text-ink">
              {snapshots.length ? Math.round(snapshots.reduce((a, s) => a + s.presentRate, 0) / snapshots.length) : 0}%
            </p>
            <p className="text-xs text-slate">Avg attendance (30d)</p>
          </div>
          <div>
            <p className="font-display text-2xl font-semibold text-ink">{currency(totals.cost)}</p>
            <p className="text-xs text-slate">Modeled monthly payroll</p>
          </div>
          <div>
            <p className="font-display text-2xl font-semibold text-ink">
              {snapshots.length ? Math.round(snapshots.reduce((a, s) => a + s.avgRisk, 0) / snapshots.length) : 0}
            </p>
            <p className="text-xs text-slate">Avg risk score (0-100)</p>
          </div>
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between">
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
            Scenario simulator
          </h2>
          <button onClick={resetScenario} className="text-xs font-medium text-flow hover:underline">
            Reset
          </button>
        </div>
        <p className="mt-1 text-xs text-slate">
          Every projection below recalculates instantly as you move a lever — nothing is saved or sent
          anywhere.
        </p>

        <div className="mt-4">
          <label className="text-xs font-medium text-slate">Apply attrition / hires to</label>
          <select className="input mt-1 max-w-xs" value={target} onChange={(e) => setTarget(e.target.value)}>
            <option value="__all__">Whole org (split evenly)</option>
            {departments.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>

        <div className="mt-5 grid gap-6 sm:grid-cols-2">
          <div>
            <div className="flex justify-between text-xs">
              <span className="font-medium text-slate">Attendance shock</span>
              <span className="text-ink">
                {attendanceShock > 0 ? "+" : ""}
                {attendanceShock} pts
              </span>
            </div>
            <input
              type="range"
              min={-30}
              max={10}
              value={attendanceShock}
              onChange={(e) => setAttendanceShock(Number(e.target.value))}
              className="mt-2 w-full"
            />
            <p className="mt-1 text-xs text-slate">e.g. flu season, transit strike, or a wellness push</p>
          </div>

          <div>
            <div className="flex justify-between text-xs">
              <span className="font-medium text-slate">Leave surge</span>
              <span className="text-ink">+{leaveSurge}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={60}
              value={leaveSurge}
              onChange={(e) => setLeaveSurge(Number(e.target.value))}
              className="mt-2 w-full"
            />
            <p className="mt-1 text-xs text-slate">extra share of the team out on leave at any time</p>
          </div>

          <div>
            <div className="flex justify-between text-xs">
              <span className="font-medium text-slate">Attrition</span>
              <span className="text-ink">-{attrition} people</span>
            </div>
            <input
              type="range"
              min={0}
              max={10}
              value={attrition}
              onChange={(e) => setAttrition(Number(e.target.value))}
              className="mt-2 w-full"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs">
              <span className="font-medium text-slate">New hires</span>
              <span className="text-ink">+{newHires} people</span>
            </div>
            <input
              type="range"
              min={0}
              max={10}
              value={newHires}
              onChange={(e) => setNewHires(Number(e.target.value))}
              className="mt-2 w-full"
            />
          </div>
        </div>
      </Card>

      <Card>
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Projected coverage by department
        </h2>
        <div className="mt-4 h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E3E6EF" />
              <XAxis dataKey="department" tick={{ fontSize: 11, fill: "#4B5468" }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: "#4B5468" }} />
              <Tooltip />
              <Legend />
              <Bar dataKey="Current coverage" fill="#E3E6EF" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Projected coverage" fill="#3355FF" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card className="!p-0 overflow-x-auto">
        <div className="p-6 pb-0">
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
            Projected impact by department
          </h2>
        </div>
        <table className="mt-4 w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-slate">
              <th className="px-6 py-3 font-medium">Department</th>
              <th className="px-6 py-3 font-medium">Headcount</th>
              <th className="px-6 py-3 font-medium">Coverage</th>
              <th className="px-6 py-3 font-medium">Monthly cost</th>
              <th className="px-6 py-3 font-medium">Risk</th>
              <th className="px-6 py-3 font-medium">Verdict</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {results.map((r) => (
              <tr key={r.department}>
                <td className="px-6 py-3 text-ink">{r.department}</td>
                <td className="px-6 py-3 text-slate">
                  {r.headcount} <span className="text-line">→</span>{" "}
                  <span className={clsx(r.projectedHeadcount < r.headcount ? "text-bad" : "text-ink")}>
                    {r.projectedHeadcount}
                  </span>
                </td>
                <td className="px-6 py-3 text-slate">
                  {r.presentRate}% <span className="text-line">→</span>{" "}
                  <span className={clsx(r.projectedPresentRate < r.presentRate ? "text-bad" : "text-ok")}>
                    {r.projectedPresentRate}%
                  </span>
                </td>
                <td className="px-6 py-3 text-slate">
                  {currency(r.headcount * r.avgMonthlyCost)} <span className="text-line">→</span>{" "}
                  {currency(r.projectedMonthlyCost)}
                </td>
                <td className="px-6 py-3 text-slate">
                  {r.avgRisk} <span className="text-line">→</span> {r.projectedRisk}
                </td>
                <td className="px-6 py-3">
                  <span className={clsx("inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium", VERDICT_STYLE[r.coverageVerdict])}>
                    {r.coverageVerdict}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <style jsx global>{`
        .input {
          border: 1px solid #e3e6ef;
          border-radius: 10px;
          padding: 0.5rem 0.65rem;
          font-size: 0.85rem;
          width: 100%;
          background: white;
        }
        .input:focus {
          outline: none;
          border-color: #3355ff;
          box-shadow: 0 0 0 3px #e8ecff;
        }
      `}</style>
    </div>
  );
}
