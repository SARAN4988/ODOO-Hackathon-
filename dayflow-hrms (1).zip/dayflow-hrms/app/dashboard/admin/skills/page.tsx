import { createClient } from "@/lib/supabase/server";
import { SkillsTabs } from "./SkillsTabs";

export default async function AdminSkillsPage() {
  const supabase = createClient();

  const [{ data: employees }, { data: skills }] = await Promise.all([
    supabase.from("users").select("id, full_name, department").order("full_name"),
    supabase.from("skills").select("user_id, skill_name, category, proficiency"),
  ]);

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Employee Skill Graph</h1>
      <p className="mt-1 text-sm text-slate">
        See what the org is strong at, where the gaps are, and drill into any one person's profile.
      </p>
      <div className="mt-6">
        <SkillsTabs skills={(skills as any) ?? []} employees={(employees as any) ?? []} />
      </div>
    </div>
  );
}
