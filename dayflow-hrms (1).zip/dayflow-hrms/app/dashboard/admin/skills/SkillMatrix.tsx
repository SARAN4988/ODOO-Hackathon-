"use client";

import { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Tooltip,
} from "recharts";
import { Card } from "@/components/Card";
import { clsx } from "clsx";

export type SkillRow = { user_id: string; skill_name: string; category: string; proficiency: number };
export type EmployeeOption = { id: string; full_name: string; department: string | null };

function cellShade(level: number) {
  // 0 = no data, 1-5 = proficiency
  if (level === 0) return "bg-mist";
  const shades = ["bg-flow-light", "bg-flow-light", "bg-flow/40", "bg-flow/70", "bg-flow"];
  return shades[level - 1];
}

export function SkillMatrix({ skills, employees }: { skills: SkillRow[]; employees: EmployeeOption[] }) {
  const uniqueSkills = useMemo(() => Array.from(new Set(skills.map((s) => s.skill_name))).sort(), [skills]);
  const [selected, setSelected] = useState<string>(employees[0]?.id ?? "");

  const matrix = useMemo(() => {
    const byUser = new Map<string, Map<string, number>>();
    for (const s of skills) {
      const row = byUser.get(s.user_id) ?? new Map<string, number>();
      row.set(s.skill_name, s.proficiency);
      byUser.set(s.user_id, row);
    }
    return byUser;
  }, [skills]);

  const coverage = useMemo(() => {
    return uniqueSkills.map((skill) => {
      const rows = skills.filter((s) => s.skill_name === skill);
      const strong = rows.filter((s) => s.proficiency >= 3).length;
      return { skill, total: rows.length, strong };
    });
  }, [skills, uniqueSkills]);

  const selectedSkills = skills
    .filter((s) => s.user_id === selected)
    .map((s) => ({ skill: s.skill_name, proficiency: s.proficiency }));

  return (
    <div className="space-y-6">
      <Card>
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Individual skill radar
        </h2>
        <div className="mt-3">
          <select className="input max-w-xs" value={selected} onChange={(e) => setSelected(e.target.value)}>
            {employees.map((e) => (
              <option key={e.id} value={e.id}>
                {e.full_name} {e.department ? `· ${e.department}` : ""}
              </option>
            ))}
          </select>
        </div>
        <div className="mt-4 h-72">
          {selectedSkills.length === 0 ? (
            <p className="flex h-full items-center justify-center text-sm text-slate">
              No skills logged for this person yet.
            </p>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={selectedSkills} outerRadius={100}>
                <PolarGrid stroke="#E3E6EF" />
                <PolarAngleAxis dataKey="skill" tick={{ fontSize: 12, fill: "#4B5468" }} />
                <PolarRadiusAxis domain={[0, 5]} tick={{ fontSize: 10, fill: "#4B5468" }} />
                <Radar dataKey="proficiency" stroke="#3355FF" fill="#3355FF" fillOpacity={0.25} />
                <Tooltip />
              </RadarChart>
            </ResponsiveContainer>
          )}
        </div>
      </Card>

      <Card>
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">Skill coverage</h2>
        <p className="mt-1 text-xs text-slate">How many people can do each skill, and how many are strong at it (4-5 / 5).</p>
        <div className="mt-3 space-y-2">
          {coverage.map((c) => (
            <div key={c.skill} className="flex items-center gap-3 text-sm">
              <span className="w-40 shrink-0 text-ink">{c.skill}</span>
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-mist">
                <div
                  className="h-full rounded-full bg-flow"
                  style={{ width: `${employees.length ? (c.total / employees.length) * 100 : 0}%` }}
                />
              </div>
              <span className="w-28 shrink-0 text-right text-xs text-slate">
                {c.total}/{employees.length} know it · {c.strong} strong
              </span>
            </div>
          ))}
          {coverage.length === 0 && <p className="text-sm text-slate">No skills logged across the org yet.</p>}
        </div>
      </Card>

      <Card className="overflow-x-auto">
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">Org skill matrix</h2>
        <table className="mt-4 w-full text-left text-xs">
          <thead>
            <tr>
              <th className="sticky left-0 bg-white px-3 py-2 font-medium text-slate">Employee</th>
              {uniqueSkills.map((s) => (
                <th key={s} className="px-3 py-2 font-medium text-slate">
                  {s}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {employees.map((e) => (
              <tr key={e.id}>
                <td className="sticky left-0 whitespace-nowrap bg-white px-3 py-2 text-ink">{e.full_name}</td>
                {uniqueSkills.map((s) => {
                  const level = matrix.get(e.id)?.get(s) ?? 0;
                  return (
                    <td key={s} className="px-3 py-2">
                      <div
                        title={level ? `${level}/5` : "No data"}
                        className={clsx("flex h-6 w-6 items-center justify-center rounded", cellShade(level))}
                      >
                        {level > 0 ? level : ""}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <style jsx global>{`
        .input {
          border: 1px solid #e3e6ef;
          border-radius: 10px;
          padding: 0.5rem 0.65rem;
          font-size: 0.85rem;
          width: 100%;
          background: white;
        }
        .input:focus {
          outline: none;
          border-color: #3355ff;
          box-shadow: 0 0 0 3px #e8ecff;
        }
      `}</style>
    </div>
  );
}
