"use client";

import { useState } from "react";
import { SkillMatrix, type SkillRow, type EmployeeOption } from "./SkillMatrix";
import { SkillIntelligence } from "./SkillIntelligence";

export function SkillsTabs({ skills, employees }: { skills: SkillRow[]; employees: EmployeeOption[] }) {
  const [tab, setTab] = useState<"matrix" | "intelligence">("matrix");

  return (
    <div>
      <div className="mb-6 flex gap-2 border-b border-line">
        <button
          onClick={() => setTab("matrix")}
          className={`border-b-2 px-1 pb-3 text-sm font-medium ${
            tab === "matrix" ? "border-flow text-flow" : "border-transparent text-slate"
          }`}
        >
          Skill Matrix
        </button>
        <button
          onClick={() => setTab("intelligence")}
          className={`border-b-2 px-1 pb-3 text-sm font-medium ${
            tab === "intelligence" ? "border-flow text-flow" : "border-transparent text-slate"
          }`}
        >
          Skill Intelligence
        </button>
      </div>

      {tab === "matrix" ? (
        <SkillMatrix skills={skills} employees={employees} />
      ) : (
        <SkillIntelligence skills={skills} employees={employees} />
      )}
    </div>
  );
}
