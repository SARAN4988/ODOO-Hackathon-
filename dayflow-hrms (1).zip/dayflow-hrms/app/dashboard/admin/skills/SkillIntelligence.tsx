"use client";

import { useMemo } from "react";
import { clsx } from "clsx";
import { Card } from "@/components/Card";
import {
  analyzeSkillGaps,
  findMentorMatches,
  buildSkillGraph,
  type SkillRow,
  type EmployeeOption,
} from "@/lib/skillIntelligence";

const SEVERITY_STYLE: Record<string, string> = {
  Critical: "bg-bad/10 text-bad",
  Watch: "bg-warn/10 text-warn",
  Healthy: "bg-ok/10 text-ok",
};

export function SkillIntelligence({ skills, employees }: { skills: SkillRow[]; employees: EmployeeOption[] }) {
  const gaps = useMemo(() => analyzeSkillGaps(skills, employees.length), [skills, employees.length]);
  const mentorMatches = useMemo(() => findMentorMatches(skills, employees), [skills, employees]);
  const graph = useMemo(() => buildSkillGraph(skills, employees, { width: 640, height: 560 }), [skills, employees]);

  const critical = gaps.filter((g) => g.severity === "Critical");

  return (
    <div className="space-y-6">
      <Card>
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Skill gap analysis
        </h2>
        <p className="mt-1 text-xs text-slate">
          A skill is flagged when too few people have it logged, or nobody has it at a strong level — the
          kind of gap that turns into a single-point-of-failure risk.
        </p>
        {critical.length > 0 && (
          <p className="mt-3 rounded-lg bg-bad/10 px-3 py-2 text-xs font-medium text-bad">
            {critical.length} skill{critical.length === 1 ? "" : "s"} at critical coverage: {critical.map((g) => g.skill).join(", ")}
          </p>
        )}
        <div className="mt-4 space-y-2">
          {gaps.map((g) => (
            <div key={g.skill} className="flex items-center gap-3 text-sm">
              <span
                className={clsx(
                  "w-20 shrink-0 rounded-full px-2.5 py-1 text-center text-xs font-medium",
                  SEVERITY_STYLE[g.severity]
                )}
              >
                {g.severity}
              </span>
              <span className="w-40 shrink-0 text-ink">{g.skill}</span>
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-mist">
                <div className="h-full rounded-full bg-flow" style={{ width: `${g.coveragePct}%` }} />
              </div>
              <span className="w-56 shrink-0 text-right text-xs text-slate">
                {g.coveragePct}% coverage · avg {g.avgProficiency}/5 · {g.peopleStrong} strong
              </span>
            </div>
          ))}
          {gaps.length === 0 && <p className="text-sm text-slate">No skills logged across the org yet.</p>}
        </div>
      </Card>

      <Card>
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Skill network
        </h2>
        <p className="mt-1 text-xs text-slate">
          The org&apos;s top skills (inner ring) connected to everyone who&apos;s strong at them (outer
          ring, proficiency 3+). Thicker, brighter lines mean higher proficiency.
        </p>
        <div className="mt-4 flex justify-center overflow-x-auto">
          <svg viewBox="0 0 640 560" width="100%" style={{ maxWidth: 640 }}>
            {graph.edges.map((e, i) => {
              const from = graph.nodes.find((n) => n.id === e.from);
              const to = graph.nodes.find((n) => n.id === e.to);
              if (!from || !to) return null;
              const opacity = 0.25 + (e.weight / 5) * 0.5;
              return (
                <line
                  key={i}
                  x1={from.x}
                  y1={from.y}
                  x2={to.x}
                  y2={to.y}
                  stroke="#3355FF"
                  strokeWidth={e.weight / 2}
                  strokeOpacity={opacity}
                />
              );
            })}
            {graph.nodes.map((n) => (
              <g key={n.id}>
                <circle
                  cx={n.x}
                  cy={n.y}
                  r={n.kind === "skill" ? 8 : 5}
                  fill={n.kind === "skill" ? "#1F3ACC" : "#1E9E6C"}
                />
                <text
                  x={n.x}
                  y={n.y - (n.kind === "skill" ? 14 : 10)}
                  textAnchor="middle"
                  fontSize={n.kind === "skill" ? 12 : 10}
                  fontWeight={n.kind === "skill" ? 600 : 400}
                  fill="#1C2333"
                >
                  {n.label}
                </text>
              </g>
            ))}
          </svg>
        </div>
        {graph.nodes.length === 0 && (
          <p className="text-center text-sm text-slate">Not enough logged skills yet to draw a graph.</p>
        )}
      </Card>

      <Card className="!p-0">
        <div className="p-6 pb-0">
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
            Suggested mentor matches
          </h2>
          <p className="mt-1 text-xs text-slate">
            Someone strong (4-5/5) paired with someone just starting out (1-2/5) on the same skill.
          </p>
        </div>
        <table className="mt-4 w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-slate">
              <th className="px-6 py-3 font-medium">Skill</th>
              <th className="px-6 py-3 font-medium">Mentor</th>
              <th className="px-6 py-3 font-medium">Mentee</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {mentorMatches.map((m, i) => (
              <tr key={i}>
                <td className="px-6 py-3 text-ink">{m.skill}</td>
                <td className="px-6 py-3 text-slate">
                  {m.mentorName} <span className="text-xs text-ok">({m.mentorLevel}/5)</span>
                </td>
                <td className="px-6 py-3 text-slate">
                  {m.menteeName} <span className="text-xs text-warn">({m.menteeLevel}/5)</span>
                </td>
              </tr>
            ))}
            {mentorMatches.length === 0 && (
              <tr>
                <td colSpan={3} className="px-6 py-6 text-center text-sm text-slate">
                  No obvious mentor pairings yet — need both strong and early-level people on the same
                  skill.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
