import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/Card";
import { StatusBadge } from "@/components/StatusBadge";

export default async function AdminOverview() {
  const supabase = createClient();
  const todayStr = new Date().toISOString().slice(0, 10);

  const [{ count: employeeCount }, { count: presentToday }, { data: pendingLeave }] =
    await Promise.all([
      supabase.from("users").select("*", { count: "exact", head: true }),
      supabase
        .from("attendance")
        .select("*", { count: "exact", head: true })
        .eq("date", todayStr)
        .eq("status", "present"),
      supabase
        .from("leave_requests")
        .select("id, leave_type, start_date, end_date, status, users(full_name)")
        .eq("status", "pending")
        .order("created_at", { ascending: false })
        .limit(5),
    ]);

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="font-display text-2xl font-semibold text-ink">HR overview</h1>
      <p className="mt-1 text-sm text-slate">A snapshot of the organization today.</p>

      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <p className="text-sm text-slate">Total employees</p>
          <p className="mt-1 font-display text-3xl font-semibold text-ink">
            {employeeCount ?? 0}
          </p>
        </Card>
        <Card>
          <p className="text-sm text-slate">Present today</p>
          <p className="mt-1 font-display text-3xl font-semibold text-ink">
            {presentToday ?? 0}
          </p>
        </Card>
        <Card>
          <p className="text-sm text-slate">Pending leave requests</p>
          <p className="mt-1 font-display text-3xl font-semibold text-ink">
            {pendingLeave?.length ?? 0}
          </p>
        </Card>
      </div>

      <Card className="mt-6">
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Needs your review
        </h2>
        {!pendingLeave || pendingLeave.length === 0 ? (
          <p className="mt-3 text-sm text-slate">Nothing pending right now.</p>
        ) : (
          <ul className="mt-3 divide-y divide-line">
            {pendingLeave.map((r: any) => (
              <li key={r.id} className="flex items-center justify-between py-3 text-sm">
                <span className="text-ink">
                  {r.users?.full_name} · {r.leave_type} · {r.start_date} → {r.end_date}
                </span>
                <StatusBadge status={r.status} />
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
