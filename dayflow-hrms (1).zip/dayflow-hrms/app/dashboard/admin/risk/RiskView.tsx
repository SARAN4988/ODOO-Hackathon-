"use client";

import { useState } from "react";
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import { Card } from "@/components/Card";

const DEPT_COLORS = ["#3355FF", "#1E9E6C", "#C98A1B", "#D8475C", "#8A7BFF", "#0EA5B7"];

export type EmployeeRisk = {
  id: string;
  name: string;
  department: string;
  dimensions: { attendanceRisk: number; leaveOveruse: number; feedbackRisk: number; tenureRisk: number };
  overall: number;
  absenteeism: { riskPercent: number; label: string; trendingUp: boolean };
};

export function RiskView({
  employeeRisks,
  departmentRadar,
  departments,
}: {
  employeeRisks: EmployeeRisk[];
  departmentRadar: Record<string, number | string>[];
  departments: string[];
}) {
  const [tab, setTab] = useState<"radar" | "predictive">("radar");

  const topAtRisk = [...employeeRisks].sort((a, b) => b.overall - a.overall).slice(0, 8);
  const likelyAbsent = [...employeeRisks]
    .sort((a, b) => b.absenteeism.riskPercent - a.absenteeism.riskPercent)
    .slice(0, 10);
  const absenteeismChartData = likelyAbsent.map((e) => ({ name: e.name, riskPercent: e.absenteeism.riskPercent }));

  return (
    <div>
      <div className="mb-6 flex gap-2 border-b border-line">
        <button
          onClick={() => setTab("radar")}
          className={`border-b-2 px-1 pb-3 text-sm font-medium ${
            tab === "radar" ? "border-flow text-flow" : "border-transparent text-slate"
          }`}
        >
          Workforce Risk Radar
        </button>
        <button
          onClick={() => setTab("predictive")}
          className={`border-b-2 px-1 pb-3 text-sm font-medium ${
            tab === "predictive" ? "border-flow text-flow" : "border-transparent text-slate"
          }`}
        >
          Predictive Absenteeism
        </button>
      </div>

      {tab === "radar" && (
        <div className="space-y-6">
          <Card>
            <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
              Risk profile by department
            </h2>
            <p className="mt-1 text-xs text-slate">
              Each axis is 0 (lowest risk) to 100 (highest), averaged across everyone in that department.
            </p>
            <div className="mt-4 h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={departmentRadar} outerRadius={110}>
                  <PolarGrid stroke="#E3E6EF" />
                  <PolarAngleAxis dataKey="dimension" tick={{ fontSize: 12, fill: "#4B5468" }} />
                  <PolarRadiusAxis domain={[0, 100]} tick={{ fontSize: 10, fill: "#4B5468" }} />
                  {departments.map((dept, i) => (
                    <Radar
                      key={dept}
                      name={dept}
                      dataKey={dept}
                      stroke={DEPT_COLORS[i % DEPT_COLORS.length]}
                      fill={DEPT_COLORS[i % DEPT_COLORS.length]}
                      fillOpacity={0.12}
                    />
                  ))}
                  <Legend />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="!p-0">
            <div className="p-6 pb-0">
              <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
                Most at-risk employees
              </h2>
              <p className="mt-1 text-xs text-slate">Ranked by overall score — a blend of attendance, leave use, feedback and tenure.</p>
            </div>
            <table className="mt-4 w-full text-left text-sm">
              <thead>
                <tr className="border-b border-line text-xs text-slate">
                  <th className="px-6 py-3 font-medium">Employee</th>
                  <th className="px-6 py-3 font-medium">Department</th>
                  <th className="px-6 py-3 font-medium">Attendance</th>
                  <th className="px-6 py-3 font-medium">Leave use</th>
                  <th className="px-6 py-3 font-medium">Feedback</th>
                  <th className="px-6 py-3 font-medium">Tenure</th>
                  <th className="px-6 py-3 font-medium">Overall</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {topAtRisk.map((e) => (
                  <tr key={e.id}>
                    <td className="px-6 py-3 text-ink">{e.name}</td>
                    <td className="px-6 py-3 text-slate">{e.department}</td>
                    <td className="px-6 py-3 text-slate">{e.dimensions.attendanceRisk}</td>
                    <td className="px-6 py-3 text-slate">{e.dimensions.leaveOveruse}</td>
                    <td className="px-6 py-3 text-slate">{e.dimensions.feedbackRisk}</td>
                    <td className="px-6 py-3 text-slate">{e.dimensions.tenureRisk}</td>
                    <td className="px-6 py-3 font-semibold text-ink">{e.overall}</td>
                  </tr>
                ))}
                {topAtRisk.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-6 py-6 text-center text-slate">
                      Not enough data yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            <div className="h-2" />
          </Card>
        </div>
      )}

      {tab === "predictive" && (
        <div className="space-y-6">
          <Card>
            <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
              Estimated absence risk, next 7 days
            </h2>
            <p className="mt-1 text-xs text-slate">
              A rule-based estimate from each person's own recent-vs-baseline attendance pattern — not a
              disciplinary judgement, and not a medical assessment.
            </p>
            <div className="mt-4 h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={absenteeismChartData} layout="vertical" margin={{ left: 16 }}>
                  <CartesianGrid stroke="#E3E6EF" horizontal={false} />
                  <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11, fill: "#4B5468" }} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: "#4B5468" }} width={110} />
                  <Tooltip formatter={(v: number) => [`${v}%`, "Absence risk"]} />
                  <Bar dataKey="riskPercent" fill="#C98A1B" radius={[0, 6, 6, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="!p-0">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-line text-xs text-slate">
                  <th className="px-6 py-3 font-medium">Employee</th>
                  <th className="px-6 py-3 font-medium">Department</th>
                  <th className="px-6 py-3 font-medium">Risk level</th>
                  <th className="px-6 py-3 font-medium">Trend</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {likelyAbsent.map((e) => (
                  <tr key={e.id}>
                    <td className="px-6 py-3 text-ink">{e.name}</td>
                    <td className="px-6 py-3 text-slate">{e.department}</td>
                    <td className="px-6 py-3">
                      <span
                        className={
                          e.absenteeism.label === "Elevated"
                            ? "text-bad font-medium"
                            : e.absenteeism.label === "Moderate"
                            ? "text-warn font-medium"
                            : "text-ok font-medium"
                        }
                      >
                        {e.absenteeism.label} ({e.absenteeism.riskPercent}%)
                      </span>
                    </td>
                    <td className="px-6 py-3 text-slate">{e.absenteeism.trendingUp ? "↑ rising" : "→ steady"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="h-2" />
          </Card>
        </div>
      )}
    </div>
  );
}
