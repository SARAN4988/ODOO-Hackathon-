import { createClient } from "@/lib/supabase/server";
import { buildRiskProfile } from "@/lib/analytics";
import { RiskView, type EmployeeRisk } from "./RiskView";

const DIMENSION_LABELS: Record<string, string> = {
  attendanceRisk: "Attendance Risk",
  leaveOveruse: "Leave Overuse",
  feedbackRisk: "Feedback Risk",
  tenureRisk: "Tenure Risk",
};

export default async function RiskPage() {
  const supabase = createClient();
  const now = new Date();
  const cutoff90 = new Date(now);
  cutoff90.setDate(cutoff90.getDate() - 90);
  const cutoff12mo = new Date(now);
  cutoff12mo.setMonth(cutoff12mo.getMonth() - 12);

  const [{ data: users }, { data: attendance }, { data: leaves }, { data: feedback }] = await Promise.all([
    supabase.from("users").select("id, full_name, department, date_joined").eq("role", "employee"),
    supabase.from("attendance").select("user_id, date, status").gte("date", cutoff90.toISOString().slice(0, 10)),
    supabase
      .from("leave_requests")
      .select("user_id, start_date, end_date, status")
      .gte("created_at", cutoff12mo.toISOString()),
    supabase.from("feedback").select("user_id, rating"),
  ]);

  const attendanceByUser = new Map<string, any[]>();
  for (const a of (attendance ?? []) as any[]) {
    const arr = attendanceByUser.get(a.user_id) ?? [];
    arr.push(a);
    attendanceByUser.set(a.user_id, arr);
  }
  const leavesByUser = new Map<string, any[]>();
  for (const l of (leaves ?? []) as any[]) {
    const arr = leavesByUser.get(l.user_id) ?? [];
    arr.push(l);
    leavesByUser.set(l.user_id, arr);
  }
  const feedbackByUser = new Map<string, number[]>();
  for (const f of (feedback ?? []) as any[]) {
    const arr = feedbackByUser.get(f.user_id) ?? [];
    arr.push(f.rating);
    feedbackByUser.set(f.user_id, arr);
  }

  const employeeRisks: EmployeeRisk[] = ((users ?? []) as any[]).map((u) => {
    const ratings = feedbackByUser.get(u.id) ?? [];
    const avgFeedbackRating = ratings.length ? ratings.reduce((a, b) => a + b, 0) / ratings.length : null;
    const { dimensions, overall, absenteeism } = buildRiskProfile({
      attendance: attendanceByUser.get(u.id) ?? [],
      leaves: leavesByUser.get(u.id) ?? [],
      avgFeedbackRating,
      dateJoined: u.date_joined,
    });
    return {
      id: u.id,
      name: u.full_name,
      department: u.department || "Unassigned",
      dimensions,
      overall,
      absenteeism,
    };
  });

  // Department-level radar: average each dimension across everyone in the department.
  const departments = Array.from(new Set(employeeRisks.map((e) => e.department))).slice(0, 6);
  const dimensionKeys = Object.keys(DIMENSION_LABELS) as (keyof EmployeeRisk["dimensions"])[];
  const departmentRadar = dimensionKeys.map((key) => {
    const row: Record<string, number | string> = { dimension: DIMENSION_LABELS[key] };
    for (const dept of departments) {
      const inDept = employeeRisks.filter((e) => e.department === dept);
      const avg = inDept.length ? inDept.reduce((s, e) => s + e.dimensions[key], 0) / inDept.length : 0;
      row[dept] = Math.round(avg);
    }
    return row;
  });

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Workforce Risk &amp; Predictions</h1>
      <p className="mt-1 text-sm text-slate">
        Spot patterns in attendance, leave use, feedback and tenure before they become attrition or coverage
        problems.
      </p>
      <div className="mt-6">
        <RiskView employeeRisks={employeeRisks} departmentRadar={departmentRadar} departments={departments} />
      </div>
    </div>
  );
}
