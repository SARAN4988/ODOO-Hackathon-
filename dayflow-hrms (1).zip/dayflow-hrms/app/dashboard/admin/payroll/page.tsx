"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Card } from "@/components/Card";
import { Field } from "@/components/AuthShell";

type EmployeeOption = { id: string; full_name: string; employee_id: string };

export default function AdminPayrollPage() {
  const supabase = createClient();
  const [employees, setEmployees] = useState<EmployeeOption[]>([]);
  const [selected, setSelected] = useState<string>("");
  const [baseSalary, setBaseSalary] = useState("");
  const [housingAllowance, setHousingAllowance] = useState("");
  const [tax, setTax] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    async function load() {
      const { data } = await supabase
        .from("users")
        .select("id, full_name, employee_id")
        .eq("role", "employee")
        .order("full_name");
      setEmployees(data ?? []);
    }
    load();
  }, [supabase]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!selected) return;
    setSaving(true);
    setSaved(false);

    const {
      data: { user },
    } = await supabase.auth.getUser();

    await supabase.from("salary_structures").insert({
      user_id: selected,
      base_salary: Number(baseSalary),
      allowances: housingAllowance ? { housing: Number(housingAllowance) } : {},
      deductions: tax ? { tax: Number(tax) } : {},
      updated_by: user?.id,
    });

    setSaving(false);
    setSaved(true);
    setBaseSalary("");
    setHousingAllowance("");
    setTax("");
  }

  return (
    <div className="mx-auto max-w-lg">
      <h1 className="font-display text-2xl font-semibold text-ink">Payroll</h1>
      <p className="mt-1 text-sm text-slate">
        Set or update an employee's salary structure. This creates a new effective record.
      </p>

      <Card className="mt-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Employee">
            <select
              required
              className="input"
              value={selected}
              onChange={(e) => setSelected(e.target.value)}
            >
              <option value="">Select an employee</option>
              {employees.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.full_name} ({e.employee_id})
                </option>
              ))}
            </select>
          </Field>

          <Field label="Base salary">
            <input
              required
              type="number"
              min={0}
              className="input"
              value={baseSalary}
              onChange={(e) => setBaseSalary(e.target.value)}
              placeholder="5000"
            />
          </Field>

          <div className="grid grid-cols-2 gap-4">
            <Field label="Housing allowance">
              <input
                type="number"
                min={0}
                className="input"
                value={housingAllowance}
                onChange={(e) => setHousingAllowance(e.target.value)}
                placeholder="0"
              />
            </Field>
            <Field label="Tax deduction">
              <input
                type="number"
                min={0}
                className="input"
                value={tax}
                onChange={(e) => setTax(e.target.value)}
                placeholder="0"
              />
            </Field>
          </div>

          {saved && <p className="text-sm text-ok">Salary structure saved.</p>}

          <button type="submit" disabled={saving} className="btn-primary">
            {saving ? "Saving…" : "Save salary structure"}
          </button>
        </form>
      </Card>

      <style jsx global>{`
        .input {
          width: 100%;
          border: 1px solid #e3e6ef;
          border-radius: 10px;
          padding: 0.5rem 0.65rem;
          font-size: 0.875rem;
        }
        .input:focus {
          outline: none;
          border-color: #3355ff;
          box-shadow: 0 0 0 3px #e8ecff;
        }
        .btn-primary {
          background: #3355ff;
          color: white;
          font-weight: 500;
          font-size: 0.875rem;
          border-radius: 10px;
          padding: 0.55rem 1.1rem;
        }
        .btn-primary:disabled {
          opacity: 0.6;
        }
      `}</style>
    </div>
  );
}
