import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/Card";
import { StatusBadge } from "@/components/StatusBadge";

export default async function AdminAttendancePage() {
  const supabase = createClient();
  const todayStr = new Date().toISOString().slice(0, 10);

  const { data: rows } = await supabase
    .from("attendance")
    .select("id, date, check_in, check_out, status, users(full_name, employee_id)")
    .eq("date", todayStr)
    .order("check_in", { ascending: true });

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Attendance</h1>
      <p className="mt-1 text-sm text-slate">Today's check-ins across the organization.</p>

      <Card className="mt-6 !p-0">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-slate">
              <th className="px-6 py-3 font-medium">Employee</th>
              <th className="px-6 py-3 font-medium">Employee ID</th>
              <th className="px-6 py-3 font-medium">Check in</th>
              <th className="px-6 py-3 font-medium">Check out</th>
              <th className="px-6 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {rows?.map((r: any) => (
              <tr key={r.id}>
                <td className="px-6 py-3 text-ink">{r.users?.full_name}</td>
                <td className="px-6 py-3 text-slate">{r.users?.employee_id}</td>
                <td className="px-6 py-3 text-slate">
                  {r.check_in ? new Date(r.check_in).toLocaleTimeString() : "—"}
                </td>
                <td className="px-6 py-3 text-slate">
                  {r.check_out ? new Date(r.check_out).toLocaleTimeString() : "—"}
                </td>
                <td className="px-6 py-3">
                  <StatusBadge status={r.status} />
                </td>
              </tr>
            ))}
            {(!rows || rows.length === 0) && (
              <tr>
                <td colSpan={5} className="px-6 py-6 text-center text-slate">
                  No one has checked in yet today.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
