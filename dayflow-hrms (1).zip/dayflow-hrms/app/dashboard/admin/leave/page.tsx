"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Card } from "@/components/Card";
import { StatusBadge } from "@/components/StatusBadge";

type LeaveRow = {
  id: string;
  leave_type: string;
  start_date: string;
  end_date: string;
  remarks: string | null;
  status: string;
  admin_comment: string | null;
  users: { full_name: string; employee_id: string } | null;
};

export default function AdminLeavePage() {
  const supabase = createClient();
  const [rows, setRows] = useState<LeaveRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [comments, setComments] = useState<Record<string, string>>({});
  const [busyId, setBusyId] = useState<string | null>(null);

  async function load() {
    const { data } = await supabase
      .from("leave_requests")
      .select("id, leave_type, start_date, end_date, remarks, status, admin_comment, users(full_name, employee_id)")
      .order("created_at", { ascending: false });

    setRows((data as any) ?? []);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleDecision(id: string, status: "approved" | "rejected") {
    setBusyId(id);
    const {
      data: { user },
    } = await supabase.auth.getUser();

    await supabase
      .from("leave_requests")
      .update({
        status,
        admin_comment: comments[id] || null,
        reviewed_by: user?.id,
      })
      .eq("id", id);

    setBusyId(null);
    load();
  }

  const pending = rows.filter((r) => r.status === "pending");
  const reviewed = rows.filter((r) => r.status !== "pending");

  return (
    <div className="mx-auto max-w-4xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Leave approvals</h1>
      <p className="mt-1 text-sm text-slate">Review and act on time-off requests.</p>

      <Card className="mt-6">
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Pending ({pending.length})
        </h2>

        {loading ? (
          <p className="mt-3 text-sm text-slate">Loading…</p>
        ) : pending.length === 0 ? (
          <p className="mt-3 text-sm text-slate">Nothing waiting on you.</p>
        ) : (
          <ul className="mt-3 divide-y divide-line">
            {pending.map((r) => (
              <li key={r.id} className="py-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-ink">
                      {r.users?.full_name}{" "}
                      <span className="font-normal text-slate">({r.users?.employee_id})</span>
                    </p>
                    <p className="mt-0.5 text-sm capitalize text-slate">
                      {r.leave_type} · {r.start_date} → {r.end_date}
                    </p>
                    {r.remarks && (
                      <p className="mt-1 text-xs text-slate">Note: {r.remarks}</p>
                    )}
                  </div>
                  <StatusBadge status={r.status} />
                </div>

                <div className="mt-3 flex items-center gap-2">
                  <input
                    className="input flex-1"
                    placeholder="Add a comment (optional)"
                    value={comments[r.id] ?? ""}
                    onChange={(e) =>
                      setComments((c) => ({ ...c, [r.id]: e.target.value }))
                    }
                  />
                  <button
                    onClick={() => handleDecision(r.id, "approved")}
                    disabled={busyId === r.id}
                    className="btn-ok"
                  >
                    Approve
                  </button>
                  <button
                    onClick={() => handleDecision(r.id, "rejected")}
                    disabled={busyId === r.id}
                    className="btn-bad"
                  >
                    Reject
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card className="mt-6">
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Reviewed
        </h2>
        {reviewed.length === 0 ? (
          <p className="mt-3 text-sm text-slate">No reviewed requests yet.</p>
        ) : (
          <ul className="mt-3 divide-y divide-line">
            {reviewed.map((r) => (
              <li key={r.id} className="flex items-center justify-between py-3 text-sm">
                <span className="text-ink">
                  {r.users?.full_name} · {r.leave_type} · {r.start_date} → {r.end_date}
                </span>
                <StatusBadge status={r.status} />
              </li>
            ))}
          </ul>
        )}
      </Card>

      <style jsx global>{`
        .input {
          border: 1px solid #e3e6ef;
          border-radius: 10px;
          padding: 0.45rem 0.65rem;
          font-size: 0.8rem;
        }
        .input:focus {
          outline: none;
          border-color: #3355ff;
          box-shadow: 0 0 0 3px #e8ecff;
        }
        .btn-ok {
          background: #1e9e6c;
          color: white;
          font-size: 0.8rem;
          font-weight: 500;
          border-radius: 8px;
          padding: 0.45rem 0.8rem;
          white-space: nowrap;
        }
        .btn-bad {
          background: #d8475c;
          color: white;
          font-size: 0.8rem;
          font-weight: 500;
          border-radius: 8px;
          padding: 0.45rem 0.8rem;
          white-space: nowrap;
        }
        .btn-ok:disabled,
        .btn-bad:disabled {
          opacity: 0.5;
        }
      `}</style>
    </div>
  );
}
