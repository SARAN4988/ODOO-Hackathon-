import { createClient } from "@/lib/supabase/server";
import { LeaveReportsCharts } from "./LeaveReportsCharts";
import { daysBetween, monthKey, monthLabel } from "@/lib/analytics";

export default async function LeaveReportsPage() {
  const supabase = createClient();
  const cutoff12mo = new Date();
  cutoff12mo.setMonth(cutoff12mo.getMonth() - 12);

  const { data: rows } = await supabase
    .from("leave_requests")
    .select("id, leave_type, start_date, end_date, status, created_at, users(full_name, department)")
    .gte("created_at", cutoff12mo.toISOString());

  const leaves = (rows ?? []) as any[];

  const typeMap = new Map<string, number>();
  const deptMap = new Map<string, number>();
  const monthMap = new Map<string, number>();
  const takerDays = new Map<string, number>();
  let totalDuration = 0;

  for (const l of leaves) {
    const type = (l.leave_type || "other").replace("_", " ");
    typeMap.set(type, (typeMap.get(type) || 0) + 1);

    const dept = l.users?.department || "Unassigned";
    deptMap.set(dept, (deptMap.get(dept) || 0) + 1);

    const mKey = monthKey(l.created_at);
    monthMap.set(mKey, (monthMap.get(mKey) || 0) + 1);

    const duration = daysBetween(l.start_date, l.end_date);
    totalDuration += duration;

    if (l.status === "approved") {
      const name = l.users?.full_name || "Unknown";
      takerDays.set(name, (takerDays.get(name) || 0) + duration);
    }
  }

  const byType = Array.from(typeMap, ([type, count]) => ({ type, count }));
  const byDepartment = Array.from(deptMap, ([department, count]) => ({ department, count }));
  const monthlyTrend = Array.from(monthMap, ([key, count]) => ({ month: monthLabel(key), count, sortKey: key }))
    .sort((a, b) => a.sortKey.localeCompare(b.sortKey))
    .slice(-12);
  const avgDuration = leaves.length ? totalDuration / leaves.length : 0;
  const topTakers = Array.from(takerDays, ([name, days]) => ({ name, days }))
    .sort((a, b) => b.days - a.days)
    .slice(0, 5);

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Leave Analytics Reports</h1>
      <p className="mt-1 text-sm text-slate">Patterns across the last 12 months of time-off requests.</p>
      <div className="mt-6">
        <LeaveReportsCharts
          byType={byType}
          monthlyTrend={monthlyTrend}
          byDepartment={byDepartment}
          avgDuration={avgDuration}
          topTakers={topTakers}
        />
      </div>
    </div>
  );
}
