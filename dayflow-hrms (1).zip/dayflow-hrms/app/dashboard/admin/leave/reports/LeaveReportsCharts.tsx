"use client";

import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  LineChart,
  Line,
} from "recharts";
import { Card } from "@/components/Card";

const PIE_COLORS = ["#3355FF", "#1E9E6C", "#C98A1B", "#D8475C", "#8A7BFF"];

export function LeaveReportsCharts({
  byType,
  monthlyTrend,
  byDepartment,
  avgDuration,
  topTakers,
}: {
  byType: { type: string; count: number }[];
  monthlyTrend: { month: string; count: number }[];
  byDepartment: { department: string; count: number }[];
  avgDuration: number;
  topTakers: { name: string; days: number }[];
}) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        <Card>
          <p className="text-xs text-slate">Total requests</p>
          <p className="mt-1 font-display text-2xl font-semibold text-ink">
            {byType.reduce((s, t) => s + t.count, 0)}
          </p>
        </Card>
        <Card>
          <p className="text-xs text-slate">Average duration</p>
          <p className="mt-1 font-display text-2xl font-semibold text-ink">{avgDuration.toFixed(1)} days</p>
        </Card>
        <Card>
          <p className="text-xs text-slate">Departments represented</p>
          <p className="mt-1 font-display text-2xl font-semibold text-ink">{byDepartment.length}</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">Requests by type</h2>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={byType} dataKey="count" nameKey="type" outerRadius={90} label>
                  {byType.map((_, i) => (
                    <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">Monthly trend</h2>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthlyTrend}>
                <CartesianGrid stroke="#E3E6EF" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#4B5468" }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "#4B5468" }} width={28} />
                <Tooltip />
                <Line type="monotone" dataKey="count" stroke="#3355FF" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">By department</h2>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={byDepartment}>
                <CartesianGrid stroke="#E3E6EF" vertical={false} />
                <XAxis dataKey="department" tick={{ fontSize: 11, fill: "#4B5468" }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "#4B5468" }} width={28} />
                <Tooltip />
                <Bar dataKey="count" fill="#8A7BFF" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
            Top leave takers (approved days)
          </h2>
          <ul className="mt-4 space-y-2">
            {topTakers.map((t) => (
              <li key={t.name} className="flex items-center gap-3 text-sm">
                <span className="w-36 shrink-0 text-ink">{t.name}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-mist">
                  <div
                    className="h-full rounded-full bg-flow"
                    style={{ width: `${Math.min((t.days / (topTakers[0]?.days || 1)) * 100, 100)}%` }}
                  />
                </div>
                <span className="w-16 shrink-0 text-right text-xs text-slate">{t.days} days</span>
              </li>
            ))}
            {topTakers.length === 0 && <p className="text-sm text-slate">No approved leave yet.</p>}
          </ul>
        </Card>
      </div>
    </div>
  );
}
