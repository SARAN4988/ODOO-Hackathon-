import { getUserProfile } from "@/lib/supabase/server";
import { CopilotChat } from "./CopilotChat";

export default async function CopilotPage() {
  const { profile } = await getUserProfile();
  const firstName = profile?.full_name?.split(" ")[0] ?? "there";

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Agentic HR Copilot</h1>
      <p className="mt-1 text-sm text-slate">
        Ask about today&apos;s attendance, leave, risk or skills — the copilot reads your live data and
        answers directly. Nothing here is a canned report; every answer is computed on the fly.
      </p>
      <div className="mt-6">
        <CopilotChat greetingName={firstName} />
      </div>
    </div>
  );
}
