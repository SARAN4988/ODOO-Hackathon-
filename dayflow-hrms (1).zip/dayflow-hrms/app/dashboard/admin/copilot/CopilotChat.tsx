"use client";

import { useRef, useState } from "react";
import { Card } from "@/components/Card";

type Message = { role: "user" | "assistant"; content: string };

const SUGGESTIONS = [
  "Who's on leave today?",
  "Who's checked in right now?",
  "Any pending leave requests?",
  "Who's highest risk right now?",
  "How many employees do we have?",
];

export function CopilotChat({ greetingName }: { greetingName: string }) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: `Hi ${greetingName} — ask me about today's attendance, leave, risk or skills. Try one of the suggestions below, or type your own question.`,
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const listRef = useRef<HTMLDivElement>(null);

  async function send(question: string) {
    const q = question.trim();
    if (!q || loading) return;
    setError(null);
    setMessages((m) => [...m, { role: "user", content: q }]);
    setInput("");
    setLoading(true);
    try {
      const res = await fetch("/api/copilot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: q }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body?.error || `Request failed (${res.status})`);
      }
      const data = await res.json();
      setMessages((m) => [...m, { role: "assistant", content: data.answer }]);
    } catch (e: any) {
      setError(e?.message || "Something went wrong.");
    } finally {
      setLoading(false);
      requestAnimationFrame(() => listRef.current?.scrollTo({ top: listRef.current.scrollHeight }));
    }
  }

  return (
    <Card className="!p-0">
      <div ref={listRef} className="max-h-[28rem] space-y-3 overflow-y-auto p-6">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] whitespace-pre-line rounded-2xl px-4 py-2.5 text-sm ${
                m.role === "user" ? "bg-flow text-white" : "bg-mist text-ink"
              }`}
            >
              {m.content}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="max-w-[80%] rounded-2xl bg-mist px-4 py-2.5 text-sm text-slate">Thinking…</div>
          </div>
        )}
      </div>

      {error && <p className="px-6 text-xs text-bad">{error}</p>}

      <div className="border-t border-line p-4">
        <div className="mb-3 flex flex-wrap gap-2">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              onClick={() => send(s)}
              disabled={loading}
              className="rounded-full border border-line bg-white px-3 py-1.5 text-xs font-medium text-slate hover:bg-mist disabled:opacity-50"
            >
              {s}
            </button>
          ))}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
          className="flex gap-2"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask the copilot…"
            className="flex-1 rounded-lg border border-line px-3 py-2 text-sm focus:border-flow focus:outline-none focus:ring-2 focus:ring-flow-light"
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className="rounded-lg bg-flow px-4 py-2 text-sm font-medium text-white hover:bg-flow-dark disabled:opacity-50"
          >
            Send
          </button>
        </form>
      </div>
    </Card>
  );
}
