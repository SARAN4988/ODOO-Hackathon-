import { createClient } from "@/lib/supabase/server";
import { AnalyticsCharts, type AnalyticsData } from "./AnalyticsCharts";

function sumJsonbValues(obj: Record<string, number> | null | undefined): number {
  if (!obj) return 0;
  return Object.values(obj).reduce((sum: number, v) => sum + (Number(v) || 0), 0);
}

export default async function AnalyticsPage() {
  const supabase = createClient();
  const now = new Date();
  const cutoff30 = new Date(now);
  cutoff30.setDate(cutoff30.getDate() - 30);
  const cutoff30Str = cutoff30.toISOString().slice(0, 10);
  const cutoff6mo = new Date(now);
  cutoff6mo.setMonth(cutoff6mo.getMonth() - 6);

  const [
    { data: users },
    { data: attendance },
    { data: leaves },
    { data: salaries },
    { data: feedback },
  ] = await Promise.all([
    supabase.from("users").select("id, department, role"),
    supabase.from("attendance").select("date, status").gte("date", cutoff30Str),
    supabase
      .from("leave_requests")
      .select("leave_type, status, created_at")
      .gte("created_at", cutoff6mo.toISOString()),
    supabase
      .from("salary_structures")
      .select("user_id, base_salary, allowances, deductions, created_at, users(department)")
      .order("created_at", { ascending: true }),
    supabase.from("feedback").select("rating"),
  ]);

  const allUsers = users ?? [];
  const employees = allUsers.filter((u: any) => u.role === "employee");

  // ---- headcount by department ----
  const deptMap = new Map<string, number>();
  for (const u of allUsers as any[]) {
    const dept = u.department || "Unassigned";
    deptMap.set(dept, (deptMap.get(dept) || 0) + 1);
  }
  const headcountByDept = Array.from(deptMap, ([department, count]) => ({ department, count }));

  // ---- attendance trend (daily present rate) ----
  const byDate = new Map<string, { present: number; total: number }>();
  for (const a of (attendance ?? []) as any[]) {
    const bucket = byDate.get(a.date) ?? { present: 0, total: 0 };
    bucket.total += 1;
    if (a.status === "present") bucket.present += 1;
    else if (a.status === "half_day") bucket.present += 0.5;
    byDate.set(a.date, bucket);
  }
  const attendanceTrend = Array.from(byDate, ([date, v]) => ({
    date: date.slice(5), // MM-DD
    presentRate: v.total ? Math.round((v.present / v.total) * 100) : 0,
  })).sort((a, b) => a.date.localeCompare(b.date));

  const avgAttendanceRate = attendanceTrend.length
    ? Math.round(attendanceTrend.reduce((s, r) => s + r.presentRate, 0) / attendanceTrend.length)
    : 100;

  // ---- leave by type ----
  const leaveTypeMap = new Map<string, number>();
  for (const l of (leaves ?? []) as any[]) {
    const t = (l.leave_type || "other").replace("_", " ");
    leaveTypeMap.set(t, (leaveTypeMap.get(t) || 0) + 1);
  }
  const leaveByType = Array.from(leaveTypeMap, ([type, count]) => ({ type, count }));
  const pendingLeave = (leaves ?? []).filter((l: any) => l.status === "pending").length;

  // ---- payroll by department (latest salary structure per user) ----
  const latestByUser = new Map<string, any>();
  for (const s of (salaries ?? []) as any[]) {
    latestByUser.set(s.user_id, s); // rows arrive ascending by created_at, so last write wins
  }
  const payrollDeptMap = new Map<string, number>();
  let totalMonthlyPayroll = 0;
  for (const s of latestByUser.values()) {
    const net = Number(s.base_salary || 0) + sumJsonbValues(s.allowances) - sumJsonbValues(s.deductions);
    totalMonthlyPayroll += net;
    const dept = s.users?.department || "Unassigned";
    payrollDeptMap.set(dept, (payrollDeptMap.get(dept) || 0) + net);
  }
  const payrollByDept = Array.from(payrollDeptMap, ([department, cost]) => ({ department, cost }));

  const feedbackRatings = ((feedback ?? []) as any[]).map((f) => f.rating).filter((r) => typeof r === "number");
  const avgFeedbackRating = feedbackRatings.length
    ? feedbackRatings.reduce((a, b) => a + b, 0) / feedbackRatings.length
    : null;

  const data: AnalyticsData = {
    kpis: {
      totalEmployees: employees.length,
      avgAttendanceRate,
      totalMonthlyPayroll,
      pendingLeave,
      avgFeedbackRating,
    },
    attendanceTrend,
    headcountByDept,
    leaveByType,
    payrollByDept,
  };

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Advanced HR Analytics</h1>
      <p className="mt-1 text-sm text-slate">
        A consolidated view of headcount, attendance, leave and payroll across the organization.
      </p>
      <div className="mt-6">
        <AnalyticsCharts data={data} />
      </div>
    </div>
  );
}
