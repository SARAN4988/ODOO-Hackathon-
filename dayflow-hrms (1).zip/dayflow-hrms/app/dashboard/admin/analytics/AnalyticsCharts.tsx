"use client";

import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { Card } from "@/components/Card";

const PIE_COLORS = ["#3355FF", "#1E9E6C", "#C98A1B", "#D8475C", "#8A7BFF"];

export type AnalyticsData = {
  kpis: {
    totalEmployees: number;
    avgAttendanceRate: number;
    totalMonthlyPayroll: number;
    pendingLeave: number;
    avgFeedbackRating: number | null;
  };
  attendanceTrend: { date: string; presentRate: number }[];
  headcountByDept: { department: string; count: number }[];
  leaveByType: { type: string; count: number }[];
  payrollByDept: { department: string; cost: number }[];
};

function fmtINR(n: number) {
  return "₹" + Math.round(n).toLocaleString("en-IN");
}

export function AnalyticsCharts({ data }: { data: AnalyticsData }) {
  const { kpis, attendanceTrend, headcountByDept, leaveByType, payrollByDept } = data;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-5">
        <Card>
          <p className="text-xs text-slate">Total employees</p>
          <p className="mt-1 font-display text-2xl font-semibold text-ink">{kpis.totalEmployees}</p>
        </Card>
        <Card>
          <p className="text-xs text-slate">Attendance rate (30d)</p>
          <p className="mt-1 font-display text-2xl font-semibold text-ink">{kpis.avgAttendanceRate}%</p>
        </Card>
        <Card>
          <p className="text-xs text-slate">Monthly payroll cost</p>
          <p className="mt-1 font-display text-2xl font-semibold text-ink">{fmtINR(kpis.totalMonthlyPayroll)}</p>
        </Card>
        <Card>
          <p className="text-xs text-slate">Pending leave requests</p>
          <p className="mt-1 font-display text-2xl font-semibold text-ink">{kpis.pendingLeave}</p>
        </Card>
        <Card>
          <p className="text-xs text-slate">Avg. feedback rating</p>
          <p className="mt-1 font-display text-2xl font-semibold text-ink">
            {kpis.avgFeedbackRating != null ? kpis.avgFeedbackRating.toFixed(1) + " / 5" : "—"}
          </p>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
            Attendance trend — last 30 days
          </h2>
          <p className="mt-1 text-xs text-slate">Share of that day's logged attendance marked present or half-day.</p>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={attendanceTrend}>
                <CartesianGrid stroke="#E3E6EF" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#4B5468" }} minTickGap={24} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: "#4B5468" }} width={36} />
                <Tooltip formatter={(v: number) => [`${v}%`, "Present"]} />
                <Line type="monotone" dataKey="presentRate" stroke="#3355FF" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
            Headcount by department
          </h2>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={headcountByDept}>
                <CartesianGrid stroke="#E3E6EF" vertical={false} />
                <XAxis dataKey="department" tick={{ fontSize: 11, fill: "#4B5468" }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "#4B5468" }} width={28} />
                <Tooltip />
                <Bar dataKey="count" fill="#3355FF" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
            Leave requests by type
          </h2>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={leaveByType} dataKey="count" nameKey="type" outerRadius={90} label>
                  {leaveByType.map((_, i) => (
                    <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
            Payroll cost by department
          </h2>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={payrollByDept} layout="vertical" margin={{ left: 16 }}>
                <CartesianGrid stroke="#E3E6EF" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11, fill: "#4B5468" }} tickFormatter={fmtINR} />
                <YAxis type="category" dataKey="department" tick={{ fontSize: 11, fill: "#4B5468" }} width={90} />
                <Tooltip formatter={(v: number) => fmtINR(v)} />
                <Bar dataKey="cost" fill="#1E9E6C" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
    </div>
  );
}
