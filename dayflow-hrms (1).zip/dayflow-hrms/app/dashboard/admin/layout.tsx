import { redirect } from "next/navigation";
import { getUserProfile } from "@/lib/supabase/server";
import { Sidebar } from "@/components/Sidebar";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user, profile } = await getUserProfile();
  if (!user || !profile) redirect("/auth/login");
  if (profile.role !== "admin") redirect("/dashboard/employee");

  return (
    <div className="flex">
      <Sidebar role="admin" name={profile.full_name} />
      <main className="min-h-screen flex-1 bg-mist p-8">{children}</main>
    </div>
  );
}
