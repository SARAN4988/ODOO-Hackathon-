"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Card } from "@/components/Card";
import { Field } from "@/components/AuthShell";

type EmployeeForm = {
  full_name: string;
  phone: string;
  address: string;
  job_title: string;
  department: string;
};

export default function AdminEmployeeDetail() {
  const { id } = useParams<{ id: string }>();
  const supabase = createClient();
  const router = useRouter();

  const [form, setForm] = useState<EmployeeForm | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    async function load() {
      const { data } = await supabase
        .from("users")
        .select("full_name, phone, address, job_title, department")
        .eq("id", id)
        .single();

      if (data) {
        setForm({
          full_name: data.full_name ?? "",
          phone: data.phone ?? "",
          address: data.address ?? "",
          job_title: data.job_title ?? "",
          department: data.department ?? "",
        });
      }
    }
    load();
  }, [id, supabase]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setSaving(true);
    setSaved(false);

    await supabase.from("users").update(form).eq("id", id);

    setSaving(false);
    setSaved(true);
    router.refresh();
  }

  if (!form) return <p className="text-sm text-slate">Loading…</p>;

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Edit employee</h1>
      <p className="mt-1 text-sm text-slate">
        Admins can update any field on an employee's record.
      </p>

      <Card className="mt-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Full name">
            <input
              className="input"
              value={form.full_name}
              onChange={(e) => setForm({ ...form, full_name: e.target.value })}
            />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Job title">
              <input
                className="input"
                value={form.job_title}
                onChange={(e) => setForm({ ...form, job_title: e.target.value })}
              />
            </Field>
            <Field label="Department">
              <input
                className="input"
                value={form.department}
                onChange={(e) => setForm({ ...form, department: e.target.value })}
              />
            </Field>
          </div>
          <Field label="Phone">
            <input
              className="input"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
            />
          </Field>
          <Field label="Address">
            <textarea
              className="input"
              rows={2}
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
            />
          </Field>

          {saved && <p className="text-sm text-ok">Saved.</p>}

          <button type="submit" disabled={saving} className="btn-primary">
            {saving ? "Saving…" : "Save changes"}
          </button>
        </form>
      </Card>

      <style jsx global>{`
        .input {
          width: 100%;
          border: 1px solid #e3e6ef;
          border-radius: 10px;
          padding: 0.5rem 0.65rem;
          font-size: 0.875rem;
        }
        .input:focus {
          outline: none;
          border-color: #3355ff;
          box-shadow: 0 0 0 3px #e8ecff;
        }
        .btn-primary {
          background: #3355ff;
          color: white;
          font-weight: 500;
          font-size: 0.875rem;
          border-radius: 10px;
          padding: 0.55rem 1.1rem;
        }
        .btn-primary:disabled {
          opacity: 0.6;
        }
      `}</style>
    </div>
  );
}
