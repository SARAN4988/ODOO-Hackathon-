import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/Card";

export default async function EmployeesPage() {
  const supabase = createClient();
  const { data: employees } = await supabase
    .from("users")
    .select("id, full_name, employee_id, department, job_title, role")
    .order("full_name");

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Employees</h1>
      <p className="mt-1 text-sm text-slate">Switch to any employee to view or edit their record.</p>

      <Card className="mt-6 !p-0">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-slate">
              <th className="px-6 py-3 font-medium">Name</th>
              <th className="px-6 py-3 font-medium">Employee ID</th>
              <th className="px-6 py-3 font-medium">Department</th>
              <th className="px-6 py-3 font-medium">Title</th>
              <th className="px-6 py-3 font-medium">Role</th>
              <th className="px-6 py-3 font-medium" />
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {employees?.map((e) => (
              <tr key={e.id}>
                <td className="px-6 py-3 text-ink">{e.full_name}</td>
                <td className="px-6 py-3 text-slate">{e.employee_id}</td>
                <td className="px-6 py-3 text-slate">{e.department ?? "—"}</td>
                <td className="px-6 py-3 text-slate">{e.job_title ?? "—"}</td>
                <td className="px-6 py-3 capitalize text-slate">{e.role}</td>
                <td className="px-6 py-3 text-right">
                  <Link
                    href={`/dashboard/admin/employees/${e.id}`}
                    className="text-sm font-medium text-flow"
                  >
                    View
                  </Link>
                </td>
              </tr>
            ))}
            {(!employees || employees.length === 0) && (
              <tr>
                <td colSpan={6} className="px-6 py-6 text-center text-slate">
                  No employees yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
