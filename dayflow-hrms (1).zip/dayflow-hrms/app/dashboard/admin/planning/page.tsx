import { createClient } from "@/lib/supabase/server";
import { PlanningCharts, type DeptCapacity } from "./PlanningCharts";

function startOfWeek(d: Date) {
  const date = new Date(d);
  const day = date.getDay();
  const diff = (day === 0 ? -6 : 1) - day;
  date.setDate(date.getDate() + diff);
  date.setHours(0, 0, 0, 0);
  return date;
}

function toDateStr(d: Date) {
  return d.toISOString().slice(0, 10);
}

export default async function PlanningPage() {
  const supabase = createClient();

  const [{ data: users }, { data: leaves }] = await Promise.all([
    supabase.from("users").select("id, department").eq("role", "employee"),
    supabase
      .from("leave_requests")
      .select("user_id, start_date, end_date, status")
      .eq("status", "approved"),
  ]);

  const employees = (users ?? []) as { id: string; department: string | null }[];
  const approvedLeaves = (leaves ?? []) as { user_id: string; start_date: string; end_date: string }[];

  const deptOf = new Map(employees.map((e) => [e.id, e.department || "Unassigned"]));
  const headcountByDept = new Map<string, number>();
  for (const e of employees) {
    const dept = e.department || "Unassigned";
    headcountByDept.set(dept, (headcountByDept.get(dept) || 0) + 1);
  }

  const todayStr = toDateStr(new Date());
  const onLeaveTodayByDept = new Map<string, number>();
  for (const l of approvedLeaves) {
    if (l.start_date <= todayStr && l.end_date >= todayStr) {
      const dept = deptOf.get(l.user_id) || "Unassigned";
      onLeaveTodayByDept.set(dept, (onLeaveTodayByDept.get(dept) || 0) + 1);
    }
  }

  const weekStarts: Date[] = [];
  const base = startOfWeek(new Date());
  for (let i = 0; i < 4; i++) {
    const d = new Date(base);
    d.setDate(d.getDate() + i * 7);
    weekStarts.push(d);
  }
  const labels = weekStarts.map((d, i) =>
    i === 0 ? "This week" : `Wk of ${d.toLocaleDateString(undefined, { month: "short", day: "numeric" })}`
  );

  const departments = Array.from(headcountByDept.keys());
  const data: DeptCapacity[] = departments.map((dept) => {
    const headcount = headcountByDept.get(dept) || 0;
    const onLeaveToday = onLeaveTodayByDept.get(dept) || 0;
    const weeks = weekStarts.map((weekStart) => {
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);
      const weekStartStr = toDateStr(weekStart);
      const weekEndStr = toDateStr(weekEnd);
      const onLeaveThatWeek = new Set(
        approvedLeaves
          .filter((l) => (deptOf.get(l.user_id) || "Unassigned") === dept)
          .filter((l) => l.start_date <= weekEndStr && l.end_date >= weekStartStr)
          .map((l) => l.user_id)
      ).size;
      return headcount ? Math.round(((headcount - onLeaveThatWeek) / headcount) * 100) : 100;
    });
    return { department: dept, headcount, onLeaveToday, weeks };
  });

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-display text-2xl font-semibold text-ink">Workforce Planning &amp; Optimization</h1>
      <p className="mt-1 text-sm text-slate">
        See where approved leave is about to squeeze a department, before it becomes a coverage problem.
      </p>
      <div className="mt-6">
        <PlanningCharts data={data} weekLabels={labels} />
      </div>
    </div>
  );
}
