"use client";

import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { Card } from "@/components/Card";
import { clsx } from "clsx";

export type DeptCapacity = {
  department: string;
  headcount: number;
  onLeaveToday: number;
  weeks: number[]; // availability % for next 4 weeks, index 0 = this week
};

function capacityColor(pct: number) {
  if (pct >= 80) return "text-ok";
  if (pct >= 60) return "text-warn";
  return "text-bad";
}

export function PlanningCharts({ data, weekLabels }: { data: DeptCapacity[]; weekLabels: string[] }) {
  const chartData = data.map((d) => ({
    department: d.department,
    Headcount: d.headcount,
    "On leave today": d.onLeaveToday,
  }));

  return (
    <div className="space-y-6">
      <Card>
        <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
          Headcount vs. on leave today
        </h2>
        <div className="mt-4 h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid stroke="#E3E6EF" vertical={false} />
              <XAxis dataKey="department" tick={{ fontSize: 11, fill: "#4B5468" }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "#4B5468" }} width={28} />
              <Tooltip />
              <Legend />
              <Bar dataKey="Headcount" fill="#3355FF" radius={[6, 6, 0, 0]} />
              <Bar dataKey="On leave today" fill="#D8475C" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card className="!p-0 overflow-x-auto">
        <div className="p-6 pb-0">
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-slate">
            Projected coverage — next 4 weeks
          </h2>
          <p className="mt-1 text-xs text-slate">
            Available capacity assumes only approved leave already on the books. Below 60% is flagged for
            attention.
          </p>
        </div>
        <table className="mt-4 w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs text-slate">
              <th className="px-6 py-3 font-medium">Department</th>
              <th className="px-6 py-3 font-medium">Headcount</th>
              {weekLabels.map((w) => (
                <th key={w} className="px-6 py-3 font-medium">
                  {w}
                </th>
              ))}
              <th className="px-6 py-3 font-medium">Signal</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {data.map((d) => {
              const worst = Math.min(...d.weeks);
              return (
                <tr key={d.department}>
                  <td className="px-6 py-3 text-ink">{d.department}</td>
                  <td className="px-6 py-3 text-slate">{d.headcount}</td>
                  {d.weeks.map((pct, i) => (
                    <td key={i} className={clsx("px-6 py-3 font-medium", capacityColor(pct))}>
                      {pct}%
                    </td>
                  ))}
                  <td className="px-6 py-3 text-xs text-slate">
                    {worst < 60
                      ? "Consider temporary coverage or spacing out approvals."
                      : worst < 80
                      ? "Keep an eye on overlapping requests."
                      : "Healthy coverage."}
                  </td>
                </tr>
              );
            })}
            {data.length === 0 && (
              <tr>
                <td colSpan={weekLabels.length + 3} className="px-6 py-6 text-center text-slate">
                  No departments to plan for yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
        <div className="h-2" />
      </Card>
    </div>
  );
}
