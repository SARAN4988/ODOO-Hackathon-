"use client";

import { useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { AuthShell, Field } from "@/components/AuthShell";

export default function SignupPage() {
  const supabase = createClient();
  const [form, setForm] = useState({
    fullName: "",
    employeeId: "",
    email: "",
    password: "",
    role: "employee" as "employee" | "admin",
  });
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (form.password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }

    setLoading(true);

    const { data, error: signUpError } = await supabase.auth.signUp({
      email: form.email,
      password: form.password,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/verify`,
        data: {
          full_name: form.fullName,
          employee_id: form.employeeId,
          role: form.role,
        },
      },
    });

    if (signUpError) {
      setError(signUpError.message);
      setLoading(false);
      return;
    }

    // Create the matching row in the public `users` table.
    if (data.user) {
      await supabase.from("users").insert({
        id: data.user.id,
        employee_id: form.employeeId,
        email: form.email,
        full_name: form.fullName,
        role: form.role,
      });
    }

    setLoading(false);
    setSubmitted(true);
  }

  if (submitted) {
    return (
      <AuthShell title="Check your inbox">
        <p className="text-sm text-slate">
          We sent a verification link to <strong>{form.email}</strong>. Confirm
          your email, then sign in.
        </p>
        <Link
          href="/auth/login"
          className="mt-6 inline-block text-sm font-medium text-flow"
        >
          Back to sign in
        </Link>
      </AuthShell>
    );
  }

  return (
    <AuthShell title="Create your account">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Field label="Full name">
          <input
            required
            value={form.fullName}
            onChange={(e) => update("fullName", e.target.value)}
            className="input"
            placeholder="Ada Lovelace"
          />
        </Field>

        <Field label="Employee ID">
          <input
            required
            value={form.employeeId}
            onChange={(e) => update("employeeId", e.target.value)}
            className="input"
            placeholder="EMP-0142"
          />
        </Field>

        <Field label="Work email">
          <input
            required
            type="email"
            value={form.email}
            onChange={(e) => update("email", e.target.value)}
            className="input"
            placeholder="ada@company.com"
          />
        </Field>

        <Field label="Password">
          <input
            required
            type="password"
            minLength={8}
            value={form.password}
            onChange={(e) => update("password", e.target.value)}
            className="input"
            placeholder="At least 8 characters"
          />
        </Field>

        <Field label="Role">
          <select
            value={form.role}
            onChange={(e) => update("role", e.target.value as "employee" | "admin")}
            className="input"
          >
            <option value="employee">Employee</option>
            <option value="admin">HR / Admin</option>
          </select>
        </Field>

        {error && <p className="text-sm text-bad">{error}</p>}

        <button type="submit" disabled={loading} className="btn-primary w-full">
          {loading ? "Creating account…" : "Create account"}
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-slate">
        Already have an account?{" "}
        <Link href="/auth/login" className="font-medium text-flow">
          Sign in
        </Link>
      </p>
    </AuthShell>
  );
}


