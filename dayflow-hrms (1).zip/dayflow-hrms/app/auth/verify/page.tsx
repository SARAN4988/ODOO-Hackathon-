import Link from "next/link";
import { AuthShell } from "@/components/AuthShell";

export default function VerifyPage() {
  return (
    <AuthShell title="Email verified">
      <p className="text-sm text-slate">
        Your email is confirmed. You can now sign in to your account.
      </p>
      <Link href="/auth/login" className="btn-primary mt-6 inline-block text-center">
        Go to sign in
      </Link>
    </AuthShell>
  );
}
