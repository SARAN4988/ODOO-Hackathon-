import { NextResponse } from "next/server";
import { createClient, getUserProfile } from "@/lib/supabase/server";
import { answerQuery, type CopilotData } from "@/lib/copilot";

function toDateStr(d: Date) {
  return d.toISOString().slice(0, 10);
}

export async function POST(request: Request) {
  const { profile } = await getUserProfile();
  if (!profile || profile.role !== "admin") {
    return NextResponse.json({ error: "Admins only." }, { status: 403 });
  }

  let question = "";
  try {
    const body = await request.json();
    question = typeof body?.question === "string" ? body.question : "";
  } catch {
    return NextResponse.json({ error: "Expected JSON body with a `question` string." }, { status: 400 });
  }

  const supabase = createClient();
  const today = toDateStr(new Date());
  const cutoff90 = new Date();
  cutoff90.setDate(cutoff90.getDate() - 90);
  const cutoff12mo = new Date();
  cutoff12mo.setMonth(cutoff12mo.getMonth() - 12);

  const [{ data: employees }, { data: attendanceToday }, { data: attendanceHistory }, { data: leaves }, { data: skills }, { data: feedback }] =
    await Promise.all([
      supabase.from("users").select("id, full_name, department, date_joined").eq("role", "employee"),
      supabase.from("attendance").select("user_id, status, check_in, check_out").eq("date", today),
      supabase
        .from("attendance")
        .select("user_id, date, status")
        .gte("date", cutoff90.toISOString().slice(0, 10)),
      supabase
        .from("leave_requests")
        .select("user_id, leave_type, start_date, end_date, status, created_at")
        .gte("created_at", cutoff12mo.toISOString()),
      supabase.from("skills").select("user_id, skill_name, proficiency"),
      supabase.from("feedback").select("user_id, rating"),
    ]);

  const data: CopilotData = {
    today,
    employees: (employees as any) ?? [],
    attendanceToday: (attendanceToday as any) ?? [],
    attendanceHistory: (attendanceHistory as any) ?? [],
    leaves: (leaves as any) ?? [],
    skills: (skills as any) ?? [],
    feedback: (feedback as any) ?? [],
  };

  const result = answerQuery(question, data);
  return NextResponse.json(result);
}
