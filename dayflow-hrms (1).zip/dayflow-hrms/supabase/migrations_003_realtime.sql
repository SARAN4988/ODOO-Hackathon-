-- ============================================================
-- Dayflow HRMS — migration 003
-- Enables Supabase Realtime on `attendance` so the admin
-- Real-Time Workforce Monitoring board (app/dashboard/admin/monitoring)
-- updates the instant someone checks in or out — no polling.
--
-- Run this in the Supabase SQL editor AFTER migrations_002.
-- Realtime respects the existing RLS policies on `attendance`
-- (admins see every row, employees only their own), so no policy
-- changes are needed here.
-- ============================================================

alter publication supabase_realtime add table attendance;
